package com.example.jobseekers;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.jobseekers.AccountActivity.LoginActivity;
import com.example.jobseekers.BottomNav.CategoryFragment;
import com.example.jobseekers.BottomNav.HomeFragment;
import com.example.jobseekers.BottomNav.InboxFragment;
import com.example.jobseekers.BottomNav.ProfileFragment;
import com.example.jobseekers.Drawer_Fragment.AboutUsFragment;
import com.example.jobseekers.Drawer_Fragment.AddJobFragment;
import com.example.jobseekers.Drawer_Fragment.AppliedJobFragment;
import com.example.jobseekers.Drawer_Fragment.BookmarkedJobFragment;
import com.example.jobseekers.Drawer_Fragment.FeedbackFragment;
import com.example.jobseekers.Drawer_Fragment.PostedJobFragment;
import com.example.jobseekers.Drawer_Fragment.PrivacyPolicyFragment;
import com.example.jobseekers.Drawer_Fragment.TermOfUseFragment;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;


public class HomePage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private NavigationView navigationView;
    private View headerView;
    private TextView navEmail, navName;
    private DatabaseReference reference;
    private FirebaseUser user;
    private FirebaseFirestore firebaseFirestore;
    private CollectionReference collectionReference;
    private String userID;
    private long backPressedTime;
    private Toast backToast;
    private CircleImageView profilePic;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        firebaseFirestore = FirebaseFirestore.getInstance();
        collectionReference = firebaseFirestore.collection("Users");
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        headerView = navigationView.getHeaderView(0);
        profilePic = (CircleImageView)headerView.findViewById(R.id.profile_picture);
        navEmail = (TextView) headerView.findViewById(R.id.user_email);
        navName = (TextView) headerView.findViewById(R.id.user_Name);
        drawer = findViewById(R.id.draw_layout);



        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();
        reference = FirebaseDatabase.getInstance().getReference();
        navigationView.setNavigationItemSelectedListener(HomePage.this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(HomePage.this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        //user see homepage once they logged in
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        }

        navName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user != null) {
                    if (user.isAnonymous()) {
                        finish();
                        Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomePage.this, LoginActivity.class));
                    } else {
                        bottomNav.setSelectedItemId(R.id.nav_profile);
                        Fragment selectedFragment = null;
                        selectedFragment = new ProfileFragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
                        drawer.closeDrawer(GravityCompat.START);
                    }
                }
            }
        });

        firebaseFirestore.collection("Users").document(userID).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (!user.isAnonymous()) {
                    String user_FirstName = documentSnapshot.getString("FirstName");
                    String user_LastName = documentSnapshot.getString("LastName");
                    String profle_image_uri = documentSnapshot.getString("ProfilePicture");
                    String user_PhoneNo = documentSnapshot.getString("PhoneNo");

                    String email = user.getEmail();
                    String username = user_FirstName + " " + user_LastName;


                    navName.setText(username);
                    navEmail.setText(email);

                    Picasso.get()
                            .load(profle_image_uri)
                            .placeholder(R.drawable.profile_placeholder_fg)
                            .into(profilePic);

                } else {
                    navEmail.setText("");
                    navName.setText(getString(R.string.please_login));
                }
            }
        });

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        if (user != null) {
            if (user.isAnonymous()) {
                switch(menuItem.getItemId()){
                    case R.id.applied_job:
                        startActivity(new Intent(HomePage.this,LoginActivity.class));
                        Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    case R.id.bookmark:
                        startActivity(new Intent(HomePage.this,LoginActivity.class));
                        Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    case R.id.add_job:
                        startActivity(new Intent(HomePage.this,LoginActivity.class));
                        Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    case R.id.posted_job:
                        startActivity(new Intent(HomePage.this,LoginActivity.class));
                        Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    case R.id.nav_about_jobSeekers:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new AboutUsFragment()).commit();
                        break;
                    case R.id.nav_term:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new TermOfUseFragment()).commit();
                        break;
                    case R.id.nav_privacy:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new PrivacyPolicyFragment()).commit();
                        break;
                    case R.id.nav_help_feedback:
                        startActivity(new Intent(HomePage.this,LoginActivity.class));
                        Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                }

            } else {
                switch (menuItem.getItemId()) {
                    case R.id.applied_job:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new AppliedJobFragment()).commit();
                        break;
                    case R.id.bookmark:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new BookmarkedJobFragment()).commit();
                        break;
                    case R.id.add_job:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new AddJobFragment()).commit();
                        break;
                    case R.id.posted_job:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new PostedJobFragment()).commit();
                        break;
                    case R.id.nav_about_jobSeekers:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new AboutUsFragment()).commit();
                        break;
                    case R.id.nav_term:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new TermOfUseFragment()).commit();
                        break;
                    case R.id.nav_privacy:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new PrivacyPolicyFragment()).commit();
                        break;
                    case R.id.nav_help_feedback:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new FeedbackFragment()).commit();
                        break;
                    case R.id.logout:
                        if(isNetworkAvailable(HomePage.this)) {
                            FirebaseAuth.getInstance().signOut();
                            finish();
                            startActivity(new Intent(HomePage.this, LoginActivity.class));
                            Toast.makeText(HomePage.this, "Logged out", Toast.LENGTH_SHORT).show();
                            break;
                        }else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(HomePage.this, R.style.AlertDialogStyle);
                            builder.setTitle(getString(R.string.connection_error))
                                    .setMessage(getString(R.string.error_description))
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                        }
                                    });

                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                }
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Fragment selectedFragment = null;
                    if (user != null) {
                        if (user.isAnonymous()) {
                            switch (menuItem.getItemId()) {
                                case R.id.nav_home:
                                    startActivity(new Intent(HomePage.this, LoginActivity.class));
                                    Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                                    finish();
                                    break;
                                case R.id.nav_category:
                                    startActivity(new Intent(HomePage.this, LoginActivity.class));
                                    Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                                    finish();
                                    break;
                                case R.id.nav_inbox:
                                    startActivity(new Intent(HomePage.this, LoginActivity.class));
                                    Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                                    finish();
                                    break;
                                case R.id.nav_profile:
                                    startActivity(new Intent(HomePage.this, LoginActivity.class));
                                    Toast.makeText(HomePage.this, "Please Login !", Toast.LENGTH_SHORT).show();
                                    finish();
                                    break;
                            }
                        } else {
                            switch (menuItem.getItemId()) {
                                case R.id.nav_home:
                                    selectedFragment = new HomeFragment();
                                    break;
                                case R.id.nav_category:
                                    selectedFragment = new CategoryFragment();
                                    break;
                                case R.id.nav_inbox:
                                    selectedFragment = new InboxFragment();
                                    break;
                                case R.id.nav_profile:
                                    selectedFragment = new ProfileFragment();
                                    break;
                            }
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
                            return true;
                        }
                    }
                    return true;
                }
            };

    @Override
    protected void onStart(){
        super.onStart();
        Menu menu = navigationView.getMenu();
        if(isNetworkAvailable(this)){

        }else{
            AlertDialog.Builder builder = new AlertDialog.Builder(HomePage.this, R.style.AlertDialogStyle);
            builder.setTitle(getString(R.string.connection_error))
                    .setMessage(getString(R.string.error_description))
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        if(user!=null){
            if(user.isAnonymous()){
                menu.findItem(R.id.logout).setVisible(false);
            }else{
                menu.findItem(R.id.logout).setVisible(true);
            }
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
        Menu menu = navigationView.getMenu();
        if(isNetworkAvailable(this)){

        }else{
            AlertDialog.Builder builder = new AlertDialog.Builder(HomePage.this, R.style.AlertDialogStyle);
            builder.setTitle(getString(R.string.connection_error))
                    .setMessage(getString(R.string.error_description))
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        if(user!=null){
            if(user.isAnonymous()){
                menu.findItem(R.id.logout).setVisible(false);
            }else{
                menu.findItem(R.id.logout).setVisible(true);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 >System.currentTimeMillis()){
            backToast.cancel();
            super.onBackPressed();
            return;
        }else{
            backToast = Toast.makeText(HomePage.this,"Press Again to Exit",Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
