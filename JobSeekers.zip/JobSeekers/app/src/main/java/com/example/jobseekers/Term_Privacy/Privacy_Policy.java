package com.example.jobseekers.Term_Privacy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.jobseekers.R;

import java.io.InputStream;

public class Privacy_Policy extends AppCompatActivity {
    private TextView privacy_policy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy__policy);
        Toolbar toolbar = findViewById(R.id.toolbar_privacy);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        privacy_policy = (TextView) findViewById(R.id.privacy_policy);


        try {
            Resources res = getResources();
            InputStream in_s = res.openRawResource(R.raw.privacy);
            byte[] b = new byte[in_s.available()];
            in_s.read(b);
            privacy_policy.setText(new String(b));
        } catch (Exception e) {
            privacy_policy.setText("Error: can't show terms.");
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
