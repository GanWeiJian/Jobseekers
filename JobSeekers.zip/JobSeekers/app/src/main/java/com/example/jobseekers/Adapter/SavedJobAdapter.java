package com.example.jobseekers.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.Class.Job;
import com.example.jobseekers.JobDetails;
import com.example.jobseekers.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SavedJobAdapter extends FirestoreRecyclerAdapter <Job,SavedJobAdapter.SavedJobHolder>{
    private Context mContext;
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String userID = user.getUid();

    public SavedJobAdapter(Context context,@NonNull FirestoreRecyclerOptions<Job> options) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(final @NonNull SavedJobHolder holder, int position, final @NonNull Job model) {
        holder.bookmarked_jobTitle.setText(model.getJobTitle());
        holder.bookmarked_jobCategory.setText(model.getCategory());
        holder.bookmarked_jobLocation.setText(model.getLocation());
        holder.bookmarked_jobPostedDate.setText(model.getCreatedIn());
        holder.bookmarked_jobSavedDate.setText(model.getSavedIn());
        holder.bookmarked_jobDescription.setText(model.getJobDescription());

        holder.bookmarked_job_cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.bookmarked_job_cardview.setClickable(false);
                if(isNetworkAvailable(mContext)){
                    LayoutInflater inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View theView = inflater.inflate(R.layout.progress_dialog, null);
                    final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                    builder.setCancelable(false); // if you want user to wait for some process to finish,
                    builder.setView(theView);
                    final AlertDialog dialog = builder.create();
                    dialog.show();

                    firebaseFirestore.collection("All Job")
                            .document(model.getJobID())
                            .get()
                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if(task.isSuccessful()){
                                        DocumentSnapshot document = task.getResult();
                                        if(document.exists()){
                                            Intent intent = new Intent(mContext, JobDetails.class);
                                            intent.putExtra("JobID",model.getJobID());
                                            intent.putExtra("Category",model.getCategory());
                                            dialog.dismiss();
                                            holder.bookmarked_job_cardview.setClickable(true);
                                            mContext.startActivity(intent);
                                        }else{
                                            dialog.dismiss();
                                            holder.bookmarked_job_cardview.setClickable(true);
                                            AlertDialog.Builder builder = new AlertDialog.Builder(mContext,R.style.AlertDialogStyle);
                                            builder.setTitle(mContext.getString(R.string.job_deleted_title))
                                                    .setMessage(mContext.getString(R.string.job_deleted_info))
                                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialog, int which) {

                                                        }
                                                    });
                                            AlertDialog alertDialog = builder.create();
                                            alertDialog.show();
                                        }
                                    }else{
                                        Toast.makeText(mContext, "Failed", Toast.LENGTH_SHORT).show();
                                        dialog.dismiss();
                                        holder.bookmarked_job_cardview.setClickable(true);
                                    }

                                }
                            });

                }else{
                    holder.bookmarked_job_cardview.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });


        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isNetworkAvailable(mContext)){
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.confirm_title))
                            .setMessage(mContext.getString(R.string.confirm_remove))
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    firebaseFirestore.collection("Users")
                                            .document(userID)
                                            .collection("SavedJob")
                                            .document(model.getJobID())
                                            .delete()
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Toast.makeText(mContext, "Remove Successful", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(mContext, "Remove Failed", Toast.LENGTH_SHORT).show();
                                                }
                                            });

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });
    }

    @NonNull
    @Override
    public SavedJobHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.saved_job_item,parent,false);
        return new SavedJobHolder(v);
    }

    class SavedJobHolder extends RecyclerView.ViewHolder{
        CardView bookmarked_job_cardview;
        TextView bookmarked_jobTitle, bookmarked_jobDescription, bookmarked_jobCategory, bookmarked_jobLocation, bookmarked_jobPostedDate,bookmarked_jobSavedDate;
        ImageView deleteBtn;

        public SavedJobHolder(@NonNull View itemView) {
            super(itemView);
            bookmarked_job_cardview = (CardView)itemView.findViewById(R.id.bookmarked_job_cardView);
            bookmarked_jobTitle = (TextView)itemView.findViewById(R.id.text_bookmarked_job_title);
            bookmarked_jobDescription = (TextView)itemView.findViewById(R.id.text_bookmarked_job_description);
            bookmarked_jobCategory = (TextView)itemView.findViewById(R.id.text_bookmarked_job_category);
            bookmarked_jobLocation = (TextView)itemView.findViewById(R.id.text_bookmarked_job_location);
            bookmarked_jobPostedDate = (TextView)itemView.findViewById(R.id.text_bookmarked_job_posted_date);
            bookmarked_jobSavedDate = (TextView)itemView.findViewById(R.id.text_bookmarked_job_bookmarked_date);
            deleteBtn = (ImageView)itemView.findViewById(R.id.bookmarked_job_deleteBtn);
        }
    }
    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
