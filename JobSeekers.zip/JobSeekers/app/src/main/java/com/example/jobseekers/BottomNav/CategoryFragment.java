package com.example.jobseekers.BottomNav;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.jobseekers.Adapter.Category_Custom_Adapter;
import com.example.jobseekers.R;
import com.example.jobseekers.ShowCategoryJob;

public class CategoryFragment extends Fragment {
    CardView cv_it,cv_engineering,cv_banking,cv_health,cv_culinary,cv_education;
    /*
    ListView listView;
    public static String[] category={"Engineering","Banking","Health Care","Culinary Arts","Information Technology"};
    public static Integer[] thumbnails = { R.drawable.ic_engineering, R.drawable.ic_catgeory_bank,R.drawable.ic_catgeory_health,R.drawable.ic_culinary,R.drawable.ic_catgeory_it };*/


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category,container,false);
        cv_it = (CardView)view.findViewById(R.id.category_cv_it);
        cv_engineering = (CardView)view.findViewById(R.id.category_cv_engineering);
        cv_banking = (CardView)view.findViewById(R.id.category_cv_bank);
        cv_health = (CardView)view.findViewById(R.id.category_cv_health);
        cv_culinary = (CardView)view.findViewById(R.id.category_cv_culinary);
        cv_education = (CardView)view.findViewById(R.id.category_cv_education);

        cv_it.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv_it.setClickable(false);
                Intent intent = new Intent(getActivity(), ShowCategoryJob.class);
                intent.putExtra("category","Information Technology");
                startActivity(intent);
            }
        });

        cv_engineering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv_engineering.setClickable(false);
                Intent intent = new Intent(getActivity(), ShowCategoryJob.class);
                intent.putExtra("category","Engineering");
                startActivity(intent);
            }
        });

        cv_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv_banking.setClickable(false);
                Intent intent = new Intent(getActivity(), ShowCategoryJob.class);
                intent.putExtra("category","Banking");
                startActivity(intent);
            }
        });

        cv_health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv_health.setClickable(false);
                Intent intent = new Intent(getActivity(), ShowCategoryJob.class);
                intent.putExtra("category","Health Care");
                startActivity(intent);
            }
        });

        cv_culinary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv_culinary.setClickable(false);
                Intent intent = new Intent(getActivity(), ShowCategoryJob.class);
                intent.putExtra("category","Culinary Arts");
                startActivity(intent);
            }
        });

        cv_education.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv_education.setClickable(false);
                Intent intent = new Intent(getActivity(), ShowCategoryJob.class);
                intent.putExtra("category","Education");
                startActivity(intent);
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.category));
    }

    @Override
    public void onResume(){
        super.onResume();
        cv_it.setClickable(true);
        cv_engineering.setClickable(true);
        cv_health.setClickable(true);
        cv_culinary.setClickable(true);
        cv_banking.setClickable(true);
        cv_education.setClickable(true);
    }

}
