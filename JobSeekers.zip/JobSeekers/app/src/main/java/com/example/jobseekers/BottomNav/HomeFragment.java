package com.example.jobseekers.BottomNav;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.Adapter.JobAdapter;
import com.example.jobseekers.FilterJob;
import com.example.jobseekers.Class.Job;
import com.example.jobseekers.R;
import com.example.jobseekers.SearchResult;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HomeFragment extends Fragment {
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private CollectionReference jobRef = firebaseFirestore.collection("All Job");
    private RecyclerView recyclerView;
    private JobAdapter adapter;
    private TextView filterBtn;
    private String job_location, job_qualification, job_category, job_type;
    private EditText searchTxt;
    private AdView adview;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        filterBtn = (TextView) view.findViewById(R.id.filterBtn);
        recyclerView = (RecyclerView) view.findViewById(R.id.rv_job);
        searchTxt = (EditText) view.findViewById(R.id.edit_search);

        MobileAds.initialize(getActivity(),"ca-app-pub-9253971680688926/8981389753");
        adview = (AdView)view.findViewById(R.id.ads) ;
        AdRequest adRequest = new AdRequest.Builder().build();
        adview.loadAd(adRequest);

        Query query = jobRef.orderBy("CreatedInQuery", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<Job> options = new FirestoreRecyclerOptions.Builder<Job>()
                .setQuery(query, Job.class)
                .build();

        adapter = new JobAdapter(getActivity(), options);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);

        searchTxt.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    Intent intent = new Intent(getActivity(), SearchResult.class);
                    intent.putExtra("Search", searchTxt.getText().toString().trim());
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        filterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity(), R.style.MaterialThemeDialog);
                View theView = getLayoutInflater().inflate(R.layout.dialog_filter, null);
                mBuilder.setPositiveButton("Apply", null)
                        .setNegativeButton("Cancel", null);

                final Spinner spCategory = (Spinner) theView.findViewById(R.id.spFilterCategory);
                final Spinner spLocation = (Spinner) theView.findViewById(R.id.spFilterLocation);
                final Spinner spQualification = (Spinner) theView.findViewById(R.id.spFilterQualification);
                final Spinner spJobType = (Spinner) theView.findViewById(R.id.spJobType);
                final EditText salaryTxt = (EditText) theView.findViewById(R.id.filterSalary);
                final TextView closeDialogBtn = (TextView) theView.findViewById(R.id.filter_close);
                salaryTxt.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(10, 2)});

                ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.filter_category_list));
                ArrayAdapter<String> locationAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.filter_location_list));
                ArrayAdapter<String> qualificationAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.filter_job_qualification_list));
                ArrayAdapter<String> jobTypeAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.filter_job_type_list));

                categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                qualificationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                jobTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                spCategory.setAdapter(categoryAdapter);
                spLocation.setAdapter(locationAdapter);
                spQualification.setAdapter(qualificationAdapter);
                spJobType.setAdapter(jobTypeAdapter);


                spCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if (!spCategory.getSelectedItem().toString().equalsIgnoreCase("Select A Category")) {
                            job_category = parent.getItemAtPosition(position).toString();
                        } else {
                            job_category = null;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                spLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if (!spLocation.getSelectedItem().toString().equalsIgnoreCase("Select A Location")) {
                            job_location = parent.getItemAtPosition(position).toString();
                        } else {
                            job_location = null;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                spJobType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if (!spJobType.getSelectedItem().toString().equalsIgnoreCase("Select A Job Type")) {
                            job_type = parent.getItemAtPosition(position).toString();
                        } else {
                            job_type = null;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                spQualification.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if (!spQualification.getSelectedItem().toString().equalsIgnoreCase("Select A Qualification")) {
                            job_qualification = parent.getItemAtPosition(position).toString();
                        } else {
                            job_qualification = null;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                mBuilder.setView(theView);
                final AlertDialog filterDialog = mBuilder.create();
                filterDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(final DialogInterface dialog) {
                        final Button apply = filterDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                        Button cancel = filterDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
                        apply.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                apply.setClickable(false);
                                if (salaryTxt.getText().toString().isEmpty()) {
                                    apply.setClickable(true);
                                    salaryTxt.setError("Field can't be empty");
                                }
                                if (job_category == null) {
                                    apply.setClickable(true);
                                    ((TextView) spCategory.getSelectedView()).setError("Error message");
                                }
                                if (job_location == null) {
                                    apply.setClickable(true);
                                    ((TextView) spLocation.getSelectedView()).setError("Error message");
                                }
                                if (job_type == null) {
                                    apply.setClickable(true);
                                    ((TextView) spJobType.getSelectedView()).setError("Error message");
                                }
                                if (job_qualification == null) {
                                    apply.setClickable(true);
                                    ((TextView) spQualification.getSelectedView()).setError("Error message");
                                } else {
                                    Double salary = Double.parseDouble(salaryTxt.getText().toString().trim());
                                    if (salary <= 0) {
                                        salaryTxt.setError("Salary Must Be At Least RM 1");
                                    } else {
                                        apply.setClickable(true);
                                        Intent intent = new Intent(getActivity(), FilterJob.class);
                                        intent.putExtra("Category", job_category);
                                        intent.putExtra("Location", job_location);
                                        intent.putExtra("JobType", job_type);
                                        intent.putExtra("Qualification", job_qualification);
                                        intent.putExtra("Salary", salary);
                                        filterDialog.dismiss();
                                        startActivity(intent);
                                        //Toast.makeText(getActivity(), salary.toString(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        });
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                filterDialog.dismiss();
                            }
                        });
                    }
                });

                closeDialogBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        filterDialog.dismiss();
                    }
                });
                filterDialog.show();
            }
        });

        return view;

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.home));
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
        if (!isNetworkAvailable(getActivity())){
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
            builder.setTitle(getActivity().getString(R.string.connection_error))
                    .setMessage(getActivity().getString(R.string.error_description))
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }


    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;

        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }
    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
