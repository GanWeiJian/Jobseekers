package com.example.jobseekers.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.EditJob;
import com.example.jobseekers.Class.Job;
import com.example.jobseekers.R;
import com.example.jobseekers.ShowUsersApplied;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class PostedJobAdapter extends FirestoreRecyclerAdapter<Job, PostedJobAdapter.PostedJobHolder> {
    private Context mContext;
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String userID = user.getUid();

    public PostedJobAdapter(Context context, @NonNull FirestoreRecyclerOptions<Job> options) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull final PostedJobHolder holder, final int position, @NonNull final Job model) {
        holder.posted_jobTitle.setText(model.getJobTitle());
        holder.posted_jobDescription.setText(model.getJobDescription());
        holder.posted_jobPostedDate.setText(model.getCreatedIn());
        holder.posted_jobCategory.setText(model.getCategory());
        holder.posted_jobLocation.setText(model.getLocation());

        holder.editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.editBtn.setClickable(false);
                if(isNetworkAvailable(mContext)){
                    Intent intent = new Intent(mContext, EditJob.class);
                    intent.putExtra("JobID",model.getJobID());
                    intent.putExtra("JobTitle",model.getJobTitle());
                    intent.putExtra("Description",model.getJobDescription());
                    intent.putExtra("Company",model.getCompanyName());
                    intent.putExtra("Address",model.getAddress());
                    intent.putExtra("Salary",model.getSalary());
                    intent.putExtra("Phone",model.getPhone());
                    intent.putExtra("Email",model.getEmail());
                    holder.editBtn.setClickable(true);
                    mContext.startActivity(intent);
                }else{
                    holder.editBtn.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        holder.userAppliedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.userAppliedBtn.setClickable(false);
                if (isNetworkAvailable(mContext)){
                    Intent intent = new Intent(mContext, ShowUsersApplied.class);
                    intent.putExtra("JobID",model.getJobID());
                    intent.putExtra("JobName",model.getJobTitle());
                    intent.putExtra("JobCompany",model.getCompanyName());
                    holder.userAppliedBtn.setClickable(true);
                    mContext.startActivity(intent);
                }else{
                    holder.userAppliedBtn.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });


        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable(mContext)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.confirm_title))
                            .setMessage(mContext.getString(R.string.confirm_delete))
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    firebaseFirestore.collection("All Job")
                                            .document(model.getJobID())
                                            .delete();

                                    firebaseFirestore.collection("Users")
                                            .document(userID)
                                            .collection("PostedJob")
                                            .document(model.getJobID())
                                            .delete()
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Toast.makeText(mContext, "Delete Successful", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(mContext, "Delete Failed", Toast.LENGTH_SHORT).show();
                                                }
                                            });

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();


                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }

        });

    }

    @NonNull
    @Override
    public PostedJobHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.posted_job_item, parent, false);
        return new PostedJobHolder(view);
    }

    class PostedJobHolder extends RecyclerView.ViewHolder {
        CardView posted_job_cardview;
        TextView posted_jobTitle, posted_jobDescription, posted_jobCategory, posted_jobLocation, posted_jobPostedDate;
        Button deleteBtn, userAppliedBtn;
        ImageView editBtn;

        public PostedJobHolder(@NonNull View itemView) {
            super(itemView);
            posted_job_cardview = (CardView) itemView.findViewById(R.id.posted_job_cardView);
            posted_jobTitle = (TextView) itemView.findViewById(R.id.text_posted_job_title);
            posted_jobDescription = (TextView) itemView.findViewById(R.id.text_posted_job_description);
            posted_jobCategory = (TextView) itemView.findViewById(R.id.text_posted_job_category);
            posted_jobLocation = (TextView) itemView.findViewById(R.id.text_posted_job_location);
            posted_jobPostedDate = (TextView) itemView.findViewById(R.id.text_posted_job_posted_date);

            deleteBtn = (Button) itemView.findViewById(R.id.btn_delete_job);
            userAppliedBtn = (Button) itemView.findViewById(R.id.btn_show_user_applied);
            editBtn = (ImageView) itemView.findViewById(R.id.posted_job_editBtn);
        }
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
