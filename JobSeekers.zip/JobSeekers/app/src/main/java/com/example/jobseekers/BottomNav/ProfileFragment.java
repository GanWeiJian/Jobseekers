package com.example.jobseekers.BottomNav;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.jobseekers.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;

public class ProfileFragment extends Fragment {
    private TextView fullName, user_email, location;
    private TextView textResume;
    private TextView editCareer;
    private TextView your_career;
    private EditText profile_name, profile_email, profile_phoneNumber, profile_address, profile_experience, profile_location;
    private String userID;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseUser user;
    private ProgressBar progressBar;
    private Button submit_save,uploadResumeBtn;
    private NumberPicker yearPicker, monthPicker;
    private ImageView imgChoose,imgUpload;
    private String[] list;
    private int position;
    private String[] careerList;
    private int careerPosition;
    private TextView progress;
    private RelativeLayout lytResume;
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PICK_RESUME_REQUEST = 2;
    private CircleImageView profile_picture_holder;
    private Uri imageUri, resumeUri;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        firebaseFirestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();

        profile_picture_holder = (CircleImageView) view.findViewById(R.id.image_profile);
        fullName = (TextView) view.findViewById(R.id.textUserName);
        location = (TextView) view.findViewById(R.id.textUserLocation);
        user_email = (TextView) view.findViewById(R.id.textUserEmail);
        progressBar = (ProgressBar) view.findViewById(R.id.profile_progressBar);
        profile_name = (EditText) view.findViewById(R.id.edit_profile_name);
        profile_email = (EditText) view.findViewById(R.id.edit_profile_email);
        profile_phoneNumber = (EditText) view.findViewById(R.id.edit_profile_phoneNo);
        profile_address = (EditText) view.findViewById(R.id.edit_profile_address);
        profile_experience = (EditText) view.findViewById(R.id.edit_profile_experience);
        profile_location = (EditText) view.findViewById(R.id.edit_profile_location);
        submit_save = (Button) view.findViewById(R.id.button_save);
        imgChoose = (ImageView) view.findViewById(R.id.imageUpload);
        imgUpload = (ImageView)view.findViewById(R.id.imageSave);
        lytResume = (RelativeLayout) view.findViewById(R.id.lytResume);
        textResume = (TextView) view.findViewById(R.id.textResume);
        editCareer = (TextView) view.findViewById(R.id.textProfessionEdit);
        your_career = (TextView) view.findViewById(R.id.textCareer);
        uploadResumeBtn=(Button)view.findViewById(R.id.button_upload_resume);

        profile_name.setFocusable(false);
        profile_name.setClickable(false);
        profile_email.setFocusable(false);
        profile_email.setClickable(false);
        profile_experience.setFocusable(false);
        profile_experience.setClickable(true);
        profile_location.setFocusable(false);
        profile_location.setClickable(true);

        position = 0;
        list = getActivity().getResources().getStringArray(R.array.location_list);
        profile_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getActivity(), R.style.MaterialThemeDialog);
                builder.setTitle(getString(R.string.profile_hint_location))
                        .setSingleChoiceItems(list, position, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                position = which;
                                profile_location.setText(list[which]);
                                dialog.dismiss();
                            }
                        });
                android.app.AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        careerPosition = 0;
        careerList = getActivity().getResources().getStringArray(R.array.Career_list);
        editCareer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.MaterialThemeDialog);
                builder.setTitle(getString(R.string.profile_your_career))
                        .setSingleChoiceItems(careerList, careerPosition, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                careerPosition = which;
                                your_career.setText(careerList[which]);
                                dialog.dismiss();
                            }
                        });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        profile_experience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater inflater = getActivity().getLayoutInflater();
                View theView = inflater.inflate(R.layout.working_experience_picker, null);
                yearPicker = (NumberPicker) theView.findViewById(R.id.year_picker);
                monthPicker = (NumberPicker) theView.findViewById(R.id.month_picker);
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.MaterialThemeDialog);
                builder.setView(theView)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String year = Integer.toString(yearPicker.getValue());
                                String month = Integer.toString(monthPicker.getValue());
                                String experience;
                                experience = year + " Year " + month + " Month";
                                profile_experience.setText(experience);

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                yearPicker.setMinValue(0);
                yearPicker.setMaxValue(20);
                monthPicker.setMinValue(0);
                monthPicker.setMaxValue(12);
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }
        });

        imgChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        imgUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgUpload.setClickable(false);
                if(isNetworkAvailable(getActivity())){
                    uploadImageFile();
                    imgUpload.setClickable(true);
                }else{
                    imgUpload.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        lytResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openResumeChooser();
            }
        });

        uploadResumeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadResumeBtn.setClickable(false);
                if(isNetworkAvailable(getActivity())){
                    uploadResume();
                    uploadResumeBtn.setClickable(true);
                }else{
                    uploadResumeBtn.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        firebaseFirestore.collection("Users").document(userID).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (!user.isAnonymous()) {
                    String user_FirstName = documentSnapshot.getString("FirstName");
                    String user_LastName = documentSnapshot.getString("LastName");
                    String user_PhoneNo = documentSnapshot.getString("PhoneNo");
                    String user_address = documentSnapshot.getString("Address");
                    String user_location = documentSnapshot.getString("Location");
                    String user_experience = documentSnapshot.getString("Experience");
                    String user_career = documentSnapshot.getString("CareerFields");
                    String profile_image_uri = documentSnapshot.getString("ProfilePicture");
                    String user_ResumeName = documentSnapshot.getString("Resume File Name");
                    String Fullname = user_FirstName + " " + user_LastName;
                    String email = user.getEmail();

                    if (user_career == null) {
                        your_career.setText(getString(R.string.profile_your_career));
                    } else {
                        your_career.setText(user_career);
                    }

                    if (user_location == "" || user_location == null) {
                        location.setText(getString(R.string.location));
                    } else {
                        location.setText(user_location);
                    }

                    if (profile_image_uri == null) {

                    } else {
                        Picasso.get().load(profile_image_uri).into(profile_picture_holder);
                    }

                    if (user_ResumeName == null) {
                        textResume.setText(getString(R.string.profile_resume_pdf));
                    } else {
                        textResume.setText(user_ResumeName);
                    }

                    profile_name.setText(Fullname);
                    profile_email.setText(email);
                    profile_phoneNumber.setText(user_PhoneNo);
                    profile_address.setText(user_address);
                    profile_experience.setText(user_experience);
                    profile_location.setText(user_location);
                    fullName.setText(Fullname);
                    user_email.setText(email);

                } else {

                }
            }
        });

        submit_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submit_save.setClickable(false);
                progressBar.setVisibility(View.VISIBLE);
                if (isNetworkAvailable(getActivity())) {
                    final String phoneNo = profile_phoneNumber.getText().toString().trim();
                    final String address = profile_address.getText().toString().trim();
                    final String location = profile_location.getText().toString().trim();
                    final String experience = profile_experience.getText().toString().trim();
                    final String careerFields = your_career.getText().toString().trim();
                    //final String profile_picture_uri = imageUri.toString();
                    final String resumeName = textResume.getText().toString().trim();

                    if (!validatePhoneNo()) {
                        progressBar.setVisibility(View.INVISIBLE);
                        submit_save.setClickable(true);
                        return;
                    }
                    progressBar.setVisibility(View.VISIBLE);

                    StorageReference storageRef = FirebaseStorage.getInstance().getReference();
                    storageRef.child("images/" + userID).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(final Uri imageUri) {
                            String DownloadUrl = imageUri.toString();
                            FirebaseUser users = FirebaseAuth.getInstance().getCurrentUser();
                            String UserID = users.getUid();
                            Map<Object, String> userdata = new HashMap<>();
                            userdata.put("ProfilePicture", DownloadUrl);
                            firebaseFirestore.collection("Users")
                                    .document(UserID)
                                    .set(userdata, SetOptions.merge())
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            Toast.makeText(getActivity(), "Update Profile Picture Successful!", Toast.LENGTH_SHORT).show();

                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {

                                        }
                                    });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getActivity(), "No New Profile Picture Selected", Toast.LENGTH_SHORT).show();


                        }
                    });


                    StorageReference storageResumeRef = FirebaseStorage.getInstance().getReference();
                    storageResumeRef.child("resume/" + userID).getDownloadUrl()
                            .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(final Uri resumeUri) {
                                    String resumeUrl = resumeUri.toString();
                                    FirebaseUser users = FirebaseAuth.getInstance().getCurrentUser();
                                    String UserID = users.getUid();
                                    Map<Object, String> userdata = new HashMap<>();
                                    userdata.put("Resume", resumeUrl);
                                    firebaseFirestore.collection("Users")
                                            .document(UserID)
                                            .set(userdata, SetOptions.merge())
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Toast.makeText(getActivity(), "Update Resume Successful!", Toast.LENGTH_SHORT).show();

                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {


                                                }
                                            });

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getActivity(), "No New Resume Submitted", Toast.LENGTH_SHORT).show();

                                }
                            });


                    firebaseFirestore.collection("Users").document(userID).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            FirebaseUser users = FirebaseAuth.getInstance().getCurrentUser();
                            String UserID = users.getUid();
                            Map<Object, String> userdata = new HashMap<>();
                            if(phoneNo.isEmpty()){
                                userdata.put("PhoneNo",null);
                            }else{
                                userdata.put("PhoneNo", phoneNo);
                            }

                            if (address.isEmpty()){
                                userdata.put("Address",null);
                            }else{
                                userdata.put("Address", address);
                            }

                            if (location.isEmpty()){
                                userdata.put("Location",null);
                            }else{
                                userdata.put("Location", location);
                            }

                            if (experience.isEmpty()){
                                userdata.put("Experience",null);
                            }else {
                                userdata.put("Experience", experience);
                            }

                            if (careerFields.equals(getString(R.string.profile_your_career))){
                                userdata.put("CareerFields",null);
                            }else{
                                userdata.put("CareerFields", careerFields);
                            }
                            userdata.put("Resume File Name", resumeName);
                            firebaseFirestore.collection("Users")
                                    .document(UserID)
                                    .set(userdata, SetOptions.merge())
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            progressBar.setVisibility(View.GONE);
                                            submit_save.setClickable(true);
                                            Toast.makeText(getActivity(), "Update Successful!", Toast.LENGTH_SHORT).show();

                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            progressBar.setVisibility(View.GONE);
                                            Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
                                            submit_save.setClickable(true);
                                        }
                                    });


                        }

                    });

                } else {
                    progressBar.setVisibility(View.GONE);
                    submit_save.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.profile));
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean validatePhoneNo() {
        String phoneNo = profile_phoneNumber.getText().toString().trim();
        if (phoneNo.isEmpty()) {
            profile_phoneNumber.setError("Field can't be empty!");
            return false;
        } else {
            profile_phoneNumber.setError(null);
            return true;
        }

    }

    private void openResumeChooser() {
        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_RESUME_REQUEST);
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            Picasso.get().load(imageUri).into(profile_picture_holder);
        } else if (requestCode == PICK_RESUME_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            resumeUri = data.getData();
            //set the pdf file name
            Cursor returnCursor = getActivity().getContentResolver().query(resumeUri, null, null, null, null);
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            returnCursor.moveToFirst();
            textResume.setText(returnCursor.getString(nameIndex));
        }
    }

    private void uploadResume() {
        if (resumeUri != null) {
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View theView = inflater.inflate(R.layout.progress_dialog, null);
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setCancelable(false); // if you want user to wait for some process to finish,
            builder.setView(theView);
            final AlertDialog dialog = builder.create();
            dialog.show();
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReference();
            StorageReference ref = storageReference.child("resume/" + userID);
            ref.putFile(resumeUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            dialog.dismiss();
                            Toast.makeText(getActivity(), "Resume Upload Successful, Click Save to save.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            dialog.dismiss();
                            Toast.makeText(getActivity(), "Resume Upload Failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {

                        }
                    });
        } else {

        }
    }

    private void uploadImageFile() {
        if (imageUri != null) {
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View theView = inflater.inflate(R.layout.progress_dialog, null);
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setCancelable(false); // if you want user to wait for some process to finish,
            builder.setView(theView);
            progress = (TextView) theView.findViewById(R.id.loading_msg);
            final AlertDialog dialog = builder.create();
            dialog.show();
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReference();
            StorageReference ref = storageReference.child("images/" + userID);
            ref.putFile(imageUri)
                    .addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            dialog.dismiss();
                            Toast.makeText(getActivity(), "Profile Picture Upload Successful. Click Save to save.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            dialog.dismiss();
                            Toast.makeText(getActivity(), "Profile Picture Upload Failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double Progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            builder.setMessage("Uploading " + (int) Progress + "%");
                        }
                    });
        } else {

        }
    }

    @Override
    public void onStart(){
        super.onStart();
        if (!isNetworkAvailable(getActivity())){
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
            builder.setTitle(getActivity().getString(R.string.connection_error))
                    .setMessage(getActivity().getString(R.string.error_description))
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }


}
