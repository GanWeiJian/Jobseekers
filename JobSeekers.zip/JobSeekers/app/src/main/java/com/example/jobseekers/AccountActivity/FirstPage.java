package com.example.jobseekers.AccountActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobseekers.HomePage;
import com.example.jobseekers.MainActivity;
import com.example.jobseekers.R;
import com.example.jobseekers.Term_Privacy.Privacy_Policy;
import com.example.jobseekers.Term_Privacy.TermOfUse;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.w3c.dom.Text;

public class FirstPage extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button loginBtn, registerBtn;
    private ProgressBar firstPage_progressBar;
    private TextView btnTermPrivacy, btnSkip;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        loginBtn = (Button) findViewById(R.id.firstPage_login_button);
        registerBtn = (Button) findViewById(R.id.firstPage_Register_button);
        firstPage_progressBar = (ProgressBar) findViewById(R.id.firstPage_progressBar);
        btnTermPrivacy = (TextView) findViewById(R.id.firstPage_termPolicy_button);
        btnSkip = (TextView) findViewById(R.id.skip_button);
        mAuth = FirebaseAuth.getInstance();


        SpannableString ss = new SpannableString(getString(R.string.term_privacy));
        final ClickableSpan termOfUse = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(FirstPage.this, TermOfUse.class));
                firstPage_progressBar.setVisibility(View.VISIBLE);
            }
        };
        ClickableSpan privacyPolicy = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(FirstPage.this, Privacy_Policy.class));
                firstPage_progressBar.setVisibility(View.VISIBLE);

            }
        };
        ss.setSpan(termOfUse, 0, 11, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(privacyPolicy, 14, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        btnTermPrivacy.setText(ss);
        btnTermPrivacy.setMovementMethod(LinkMovementMethod.getInstance());


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FirstPage.this, LoginActivity.class));
                loginBtn.setClickable(false);
                firstPage_progressBar.setVisibility(View.VISIBLE);

            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FirstPage.this, SignUpActivity.class));
                registerBtn.setClickable(false);
                firstPage_progressBar.setVisibility(View.VISIBLE);

            }
        });

        btnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstPage_progressBar.setVisibility(View.VISIBLE);
                btnSkip.setClickable(false);
                mAuth.signInAnonymously()
                        .addOnCompleteListener(FirstPage.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (isNetworkAvailable(FirstPage.this)) {
                                    if (!task.isSuccessful()) {
                                        Toast.makeText(FirstPage.this, "Fail", Toast.LENGTH_SHORT).show();
                                        firstPage_progressBar.setVisibility(View.INVISIBLE);
                                    } else {
                                        finish();
                                        startActivity(new Intent(FirstPage.this, HomePage.class));
                                        FirebaseUser user = mAuth.getCurrentUser();
                                    }
                                } else {
                                    firstPage_progressBar.setVisibility(View.INVISIBLE);
                                    AlertDialog.Builder builder = new AlertDialog.Builder(FirstPage.this, R.style.AlertDialogStyle);
                                    builder.setTitle(getString(R.string.connection_error))
                                            .setMessage(getString(R.string.error_description))
                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                }
                                            });

                                    AlertDialog alertDialog = builder.create();
                                    alertDialog.show();
                                }
                            }
                        });
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();
        if (mAuth.getCurrentUser() != null) {
            if (user.isAnonymous()) {

            } else {
                finish();
                startActivity(new Intent(FirstPage.this, HomePage.class));
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        firstPage_progressBar.setVisibility(View.GONE);
        loginBtn.setClickable(true);
        registerBtn.setClickable(true);
        btnSkip.setClickable(true);
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
