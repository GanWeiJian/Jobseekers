package com.example.jobseekers.Adapter;

import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.R;
import com.example.jobseekers.Class.User;
import com.example.jobseekers.UserDetailsActivity;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.os.Environment.DIRECTORY_DOWNLOADS;

public class UserAdapter extends FirestoreRecyclerAdapter <User,UserAdapter.UserHolder>{
    private Context mContext;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private String userID = user.getUid();
    private DownloadManager dm;
    private String jobName,jobCompany,jobID;


    public UserAdapter(Context context,@NonNull FirestoreRecyclerOptions<User> options,String jobName,String jobCompany,String jobID) {
        super(options);
        this.mContext=context;
        this.jobName = jobName;
        this.jobCompany = jobCompany;
        this.jobID = jobID;
    }

    @Override
    protected void onBindViewHolder(@NonNull final UserHolder holder, int position, final @NonNull User model) {
        final String fullname = model.getFirstName() +" "+ model.getLastName();
        holder.username.setText(fullname);
        if(model.getProfilePicture()==null){

        }else{
            Picasso.get().load(model.getProfilePicture()).into(holder.profile_picture_holder);
        }

        if (model.getCareerFields()==null){
            holder.careerFields.setText("Unknown");
        }else{
            holder.careerFields.setText(model.getCareerFields());
        }

        if(model.getExperience()==null){
            holder.workingExperience.setText("Unknown");
        }else{
            holder.workingExperience.setText(model.getExperience());
        }
        if(model.getLocation()==null){
            holder.Location.setText("Unknown");
        }else{
            holder.Location.setText(model.getLocation());
        }

        holder.userCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.userCardView.setClickable(false);
                if(isNetworkAvailable(mContext)){
                    Intent intent = new Intent(mContext, UserDetailsActivity.class);
                    intent.putExtra("UserID",model.getID());
                    intent.putExtra("Resume",model.getResume());
                    intent.putExtra("Fullname",model.getFirstName()+" "+model.getLastName());
                    intent.putExtra("JobTitle",jobName);
                    intent.putExtra("JobCompany",jobCompany);
                    intent.putExtra("JobID",jobID);
                    holder.userCardView.setClickable(true);
                    mContext.startActivity(intent);

                }else{
                    holder.userCardView.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        holder.downloadResumeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.downloadResumeBtn.setClickable(false);
                if(isNetworkAvailable(mContext)){
                    if(model.getResume()==null){
                        holder.downloadResumeBtn.setClickable(true);
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                        builder.setMessage("User Did Not Submit Resume!")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });

                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }else{
                        holder.downloadResumeBtn.setClickable(true);
                        dm = (DownloadManager)mContext.getSystemService(Context.DOWNLOAD_SERVICE);
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(model.getResume()));
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        request.setDestinationInExternalFilesDir(mContext,DIRECTORY_DOWNLOADS,"Resume:"+fullname);
                        dm.enqueue(request);
                        Toast.makeText(mContext,"Downloading...",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    holder.downloadResumeBtn.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }


            }
        });

    }

    @NonNull
    @Override
    public UserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.users_item,parent,false);
        return new UserHolder(v);
    }

    class UserHolder extends RecyclerView.ViewHolder{
        CardView userCardView;
        CircleImageView profile_picture_holder;
        TextView username,careerFields,Location,workingExperience;
        Button downloadResumeBtn;

        public UserHolder(View itemView){
            super(itemView);
            profile_picture_holder = (CircleImageView)itemView.findViewById(R.id.user_image_profile);
            username = (TextView)itemView.findViewById(R.id.text_username);
            careerFields = (TextView)itemView.findViewById(R.id.text_user_career);
            Location = (TextView)itemView.findViewById(R.id.text_user_location);
            workingExperience = (TextView)itemView.findViewById(R.id.text_user_experience);
            downloadResumeBtn = (Button)itemView.findViewById(R.id.user_download_resume);
            userCardView = (CardView)itemView.findViewById(R.id.user_cardView);

        }
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
