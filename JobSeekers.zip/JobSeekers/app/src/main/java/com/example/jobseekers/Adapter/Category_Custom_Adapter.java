package com.example.jobseekers.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jobseekers.R;

public class Category_Custom_Adapter extends ArrayAdapter<String> {
    Context context;
    Integer[] thumbnails;
    String[] category;

    public Category_Custom_Adapter(Context context,int layoutToBeInflated, Integer[] thumbnails,String[] category){
        super(context, R.layout.row_category,category);
        this.context=context;
        this.thumbnails=thumbnails;
        this.category=category;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        View row = inflater.inflate(R.layout.row_category, null);
        TextView label = (TextView) row.findViewById(R.id.category_title);
        ImageView icon = (ImageView) row.findViewById(R.id.category_image);
        label.setText(category[position]);
        icon.setImageResource(thumbnails[position]);
        return (row);
    }// getView
}
