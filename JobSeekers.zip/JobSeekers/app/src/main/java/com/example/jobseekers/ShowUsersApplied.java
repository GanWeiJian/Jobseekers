package com.example.jobseekers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.jobseekers.Adapter.UserAdapter;
import com.example.jobseekers.Class.User;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class ShowUsersApplied extends AppCompatActivity {
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private FirebaseUser user;
    private CollectionReference jobRef;
    private UserAdapter adapter;
    private RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_users_applied);

        Intent intent = getIntent();
        String jobID = intent.getStringExtra("JobID");
        String jobName = intent.getStringExtra("JobName");
        String jobCompany = intent.getStringExtra("JobCompany");

        Toolbar toolbar = findViewById(R.id.show_applied_user_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ShowUsersApplied.this.setTitle("User Applied");

        user = FirebaseAuth.getInstance().getCurrentUser();
        String userID = user.getUid();
        recyclerView = (RecyclerView) findViewById(R.id.rv_user_applied);
        jobRef = firebaseFirestore.collection("All Job").document(jobID).collection("AppliedBy");
        Query query = jobRef.orderBy("AppliedInQuery", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<User> options = new FirestoreRecyclerOptions.Builder<User>()
                .setQuery(query, User.class)
                .build();

        adapter = new UserAdapter(ShowUsersApplied.this,options,jobName,jobCompany,jobID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ShowUsersApplied.this));
        recyclerView.setAdapter(adapter);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
