package com.example.jobseekers.BottomNav;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.Adapter.NotificationAdapter;
import com.example.jobseekers.Class.Notification;
import com.example.jobseekers.R;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class InboxFragment extends Fragment {
    private RecyclerView todayNotification,earlierNotification;
    private FirebaseFirestore firebaseFirestore;
    private CollectionReference userRef;
    private FirebaseUser user;
    private NotificationAdapter adapterToday,adapterEarlier;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_inbox,container,false);
        firebaseFirestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userRef = firebaseFirestore.collection("Users").document(user.getUid()).collection("Notification");

        Date c = Calendar.getInstance().getTime();
        System.out.println("Current time => " + c);
        SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
        String formattedDateQuery = dfdate.format(c);

        todayNotification = (RecyclerView)view.findViewById(R.id.rv_notification_today);
        todayNotification.setHasFixedSize(true);
        todayNotification.setLayoutManager(new LinearLayoutManager(getActivity()));
        earlierNotification = (RecyclerView)view.findViewById(R.id.rv_notification_earlier);
        earlierNotification.setHasFixedSize(true);
        earlierNotification.setLayoutManager(new LinearLayoutManager(getActivity()));

        Query queryToday = userRef.whereEqualTo("InterviewAcceptedDateQuery",formattedDateQuery).orderBy("InterviewAcceptedDateQuery", Query.Direction.DESCENDING);
        Query queryEarlier = userRef.whereLessThan("InterviewAcceptedDateQuery",formattedDateQuery).orderBy("InterviewAcceptedDateQuery",Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<Notification>optionsToday = new FirestoreRecyclerOptions.Builder<Notification>()
                .setQuery(queryToday,Notification.class)
                .build();
        FirestoreRecyclerOptions<Notification>optionsEarlier = new FirestoreRecyclerOptions.Builder<Notification>()
                .setQuery(queryEarlier,Notification.class)
                .build();
        adapterToday = new NotificationAdapter(getActivity(),optionsToday);
        adapterEarlier = new NotificationAdapter(getActivity(),optionsEarlier);
        todayNotification.setAdapter(adapterToday);
        earlierNotification.setAdapter(adapterEarlier);

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.inbox));
    }

    @Override
    public void onStart() {
        super.onStart();
        adapterToday.startListening();
        adapterEarlier.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapterToday.stopListening();
        adapterEarlier.startListening();
    }
}
