package com.example.jobseekers.Class;

import com.google.firebase.database.PropertyName;

public class Job {
    private String JobID,JobTitle, JobDescription,JobType, Category, CompanyName, Location, Address, Phone, Email, Qualification,CreatedIn,SavedIn,PostedBy,AppliedIn;
    private Double Salary;

    public Job() {

    }

    public Job(String JobID,String jobTitle, String jobDescription, String JobType,String jobCategory, String companyName, String location, String address, Double salary, String phoneNo, String email, String qualification,String postedDate,String savedDate,String PostedBy,
               String AppliedIn) {
        this.JobID = JobID;
        this.JobTitle = jobTitle;
        this.JobDescription = jobDescription;
        this.JobType = JobType;
        this.Category = jobCategory;
        this.CompanyName = companyName;
        this.Location = location;
        this.Address = address;
        this.Salary = salary;
        this.Phone = phoneNo;
        this.Email = email;
        this.Qualification = qualification;
        this.CreatedIn = postedDate;
        this.SavedIn = savedDate;
        this.PostedBy = PostedBy;
        this.AppliedIn = AppliedIn;
    }

    public String getAppliedIn() {
        return AppliedIn;
    }

    public String getPostedBy() {
        return PostedBy;
    }

    public String getSavedIn() {
        return SavedIn;
    }

    public String getJobID() {
        return JobID;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public String getJobDescription() {
        return JobDescription;
    }

    public String getJobType() {
        return JobType;
    }

    public String getCategory() {
        return Category;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public String getLocation() {
        return Location;
    }

    public String getAddress() {
        return Address;
    }

    public Double getSalary() {
        return Salary;
    }

    public String getPhone() {
        return Phone;
    }

    public String getEmail() {
        return Email;
    }

    public String getQualification() {
        return Qualification;
    }

    public String getCreatedIn() {
        return CreatedIn;
    }
}
