package com.example.jobseekers.Class;

public class Notification {
    private String InterviewDate,InterviewMesssage,InterviewAcceptedDate,InterviewAcceptedDateQuery,InterviewPlatform,InterviewPlatformDetails,
            InterviewTime,JobCompany,JobName,Method,JobID;

    public Notification(){

    }

    public Notification(String interviewDate, String interviewMesssage, String interviewAcceptedDate, String interviewAcceptedDateQuery, String interviewPlatform, String interviewPlatformDetails, String interviewTime, String jobCompany, String jobName, String method,String jobID) {
        InterviewDate = interviewDate;
        InterviewMesssage = interviewMesssage;
        InterviewAcceptedDate = interviewAcceptedDate;
        InterviewAcceptedDateQuery = interviewAcceptedDateQuery;
        InterviewPlatform = interviewPlatform;
        InterviewPlatformDetails = interviewPlatformDetails;
        InterviewTime = interviewTime;
        JobCompany = jobCompany;
        JobName = jobName;
        Method = method;
        JobID =jobID;
    }

    public String getJobID() {
        return JobID;
    }

    public String getInterviewDate() {
        return InterviewDate;
    }

    public String getInterviewMesssage() {
        return InterviewMesssage;
    }

    public String getInterviewAcceptedDate() {
        return InterviewAcceptedDate;
    }

    public String getInterviewAcceptedDateQuery() {
        return InterviewAcceptedDateQuery;
    }

    public String getInterviewPlatform() {
        return InterviewPlatform;
    }

    public String getInterviewPlatformDetails() {
        return InterviewPlatformDetails;
    }

    public String getInterviewTime() {
        return InterviewTime;
    }

    public String getJobCompany() {
        return JobCompany;
    }

    public String getJobName() {
        return JobName;
    }

    public String getMethod() {
        return Method;
    }
}
