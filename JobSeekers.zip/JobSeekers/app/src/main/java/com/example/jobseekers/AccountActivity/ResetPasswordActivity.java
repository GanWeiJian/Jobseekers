package com.example.jobseekers.AccountActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.jobseekers.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ResetPasswordActivity extends AppCompatActivity {
    private EditText inputEmail;
    private Button resetBtn;
    private ImageButton cancelBtn;
    private FirebaseAuth auth;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        inputEmail = (EditText)findViewById(R.id.reset_pass_text);
        resetBtn = (Button)findViewById(R.id.reset_button);
        cancelBtn = (ImageButton)findViewById(R.id.reset_cancel_button);
        progressBar = (ProgressBar)findViewById(R.id.progressBar);

        auth = FirebaseAuth.getInstance();

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isNetworkAvailable(ResetPasswordActivity.this)){
                    String email = inputEmail.getText().toString().trim();

                    if(!validateEmail()){
                        return;
                    }
                    progressBar.setVisibility(View.VISIBLE);
                    auth.sendPasswordResetEmail(email)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                         if(!task.isSuccessful()){
                                             progressBar.setVisibility(View.INVISIBLE);
                                             inputEmail.setError("Email not found!");
                                         }else{
                                             progressBar.setVisibility(View.INVISIBLE);
                                             AlertDialog.Builder builder = new AlertDialog.Builder(ResetPasswordActivity.this,R.style.AlertDialogStyle);
                                             builder.setTitle(getString(R.string.resetPassword_title))
                                                     .setMessage(getString(R.string.reset_password_instruction))
                                                     .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                         @Override
                                                         public void onClick(DialogInterface dialog, int which) {
                                                                finish();
                                                         }
                                                     });

                                             AlertDialog alertDialog = builder.create();
                                             alertDialog.show();
                                         }
                                }
                            });
                }else {
                    //Toast.makeText(SignUpActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                    AlertDialog.Builder builder = new AlertDialog.Builder(ResetPasswordActivity.this,R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }

            }
        });

    }

    private boolean validateEmail() {
        String email = inputEmail.getText().toString().trim();
        if (email.isEmpty()) {
            inputEmail.setError("Field can't be empty");
            return false;
        } else if (!isEmailValid(email)) {
            inputEmail.setError("Please Enter Correct Email");
            return false;
        } else {
            inputEmail.setError(null);
            return true;
        }
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
    }
}
