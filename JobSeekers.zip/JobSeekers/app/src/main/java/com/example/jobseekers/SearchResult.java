package com.example.jobseekers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.example.jobseekers.Adapter.JobAdapter;
import com.example.jobseekers.Class.Job;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class SearchResult extends AppCompatActivity {

    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private CollectionReference jobRef = firebaseFirestore.collection("All Job");
    private RecyclerView recyclerView;
    private JobAdapter adapter;
    private RelativeLayout resultNotFoundLyt;
    private LinearLayout resultLyt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);

        resultNotFoundLyt = (RelativeLayout)findViewById(R.id.resultNotFoundLayout);
        resultLyt = (LinearLayout)findViewById(R.id.resultLyt);

        Intent intent = getIntent();
        String search =intent.getStringExtra("Search");

        Toolbar toolbar = findViewById(R.id.result_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        SearchResult.this.setTitle(getString(R.string.search_title));

        recyclerView = (RecyclerView)findViewById(R.id.rv_result_job);
        Query query = jobRef.orderBy("JobTitle")
                .orderBy("JobDescription")
                .startAt(search.toUpperCase())
                .endAt(search.toLowerCase()+ "\uf8ff");
        FirestoreRecyclerOptions<Job> options = new FirestoreRecyclerOptions.Builder<Job>()
                .setQuery(query,Job.class)
                .build();
        adapter = new JobAdapter(SearchResult.this,options);


        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(SearchResult.this));
        recyclerView.setAdapter(adapter);




        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onStart(){
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop(){
        super.onStop();
        adapter.stopListening();
    }
}
