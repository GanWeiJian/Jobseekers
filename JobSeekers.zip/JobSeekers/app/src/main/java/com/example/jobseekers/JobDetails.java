package com.example.jobseekers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.jobseekers.Adapter.ViewPagerAdapter;
import com.example.jobseekers.JobDetailsFragment.JobDetailsFragment;
import com.example.jobseekers.JobDetailsFragment.SimilarJobFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

public class JobDetails extends AppCompatActivity {
    private TabLayout tabLayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;
    private TextView jobTitleTxt,companyTxt,DatePostedTxt,jobTypeTxt,phoneTxt,emailTxt,addressTxt,categoryTxt;
    private FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_details);
        firebaseFirestore = FirebaseFirestore.getInstance();
        String jobID = getIntent().getStringExtra("JobID");

        Toolbar toolbar = findViewById(R.id.jobDetails_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        JobDetails.this.setTitle("Job Details");

        tabLayout = (TabLayout)findViewById(R.id.tabLyt);
        appBarLayout = (AppBarLayout)findViewById(R.id.appBar);
        viewPager = (ViewPager)findViewById(R.id.view_pager);

        jobTitleTxt = (TextView)findViewById(R.id.job_details_title);
        companyTxt = (TextView)findViewById(R.id.job_details_company);
        DatePostedTxt =(TextView)findViewById(R.id.job_details_posted_date);
        categoryTxt = (TextView)findViewById(R.id.job_details_category);
        jobTypeTxt = (TextView)findViewById(R.id.job_details_job_type);
        phoneTxt = (TextView)findViewById(R.id.job_details_phone);
        emailTxt = (TextView)findViewById(R.id.job_details_email);
        addressTxt = (TextView)findViewById(R.id.job_details_address);

        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new JobDetailsFragment(),"Job Details");
        adapter.addFragment(new SimilarJobFragment(), "Similar Jobs");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        firebaseFirestore.collection("All Job").document(jobID).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String jobTitle = documentSnapshot.getString("JobTitle");
                String company = documentSnapshot.getString("CompanyName");
                String postedDate = documentSnapshot.getString("CreatedIn");
                String category = documentSnapshot.getString("Category");
                String jobType = documentSnapshot.getString("JobType");
                String phone = documentSnapshot.getString("Phone");
                String email = documentSnapshot.getString("Email");
                String address = documentSnapshot.getString("Address");

                jobTitleTxt.setText(jobTitle);
                companyTxt.setText(company);
                DatePostedTxt.setText(postedDate);
                jobTypeTxt.setText(jobType);
                phoneTxt.setText(phone);
                emailTxt.setText(email);
                categoryTxt.setText(category);
                addressTxt.setText(address);
            }
        });




        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
