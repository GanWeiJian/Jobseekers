package com.example.jobseekers.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.Class.Job;
import com.example.jobseekers.JobDetails;
import com.example.jobseekers.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class AppliedJobAdapter extends FirestoreRecyclerAdapter<Job,AppliedJobAdapter.AppliedJobHolder> {
    private Context mContext;
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

    public AppliedJobAdapter(Context context,@NonNull FirestoreRecyclerOptions<Job> options) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull AppliedJobHolder holder, int position, final @NonNull Job model) {
        holder.applied_jobTitle.setText(model.getJobTitle());
        holder.applied_jobCategory.setText(model.getCategory());
        holder.applied_jobLocation.setText(model.getLocation());
        holder.applied_jobPostedDate.setText(model.getCreatedIn());
        holder.applied_jobAppliedDate.setText(model.getAppliedIn());
        holder.applied_jobDescription.setText(model.getJobDescription());

        holder.applied_job_cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isNetworkAvailable(mContext)){
                    LayoutInflater inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View theView = inflater.inflate(R.layout.progress_dialog, null);
                    final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                    builder.setCancelable(false); // if you want user to wait for some process to finish,
                    builder.setView(theView);
                    final AlertDialog dialog = builder.create();
                    dialog.show();

                    firebaseFirestore.collection("All Job")
                            .document(model.getJobID())
                            .get()
                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if(task.isSuccessful()){
                                        DocumentSnapshot document = task.getResult();
                                        if(document.exists()){
                                            Intent intent = new Intent(mContext, JobDetails.class);
                                            intent.putExtra("JobID",model.getJobID());
                                            intent.putExtra("Category",model.getCategory());
                                            dialog.dismiss();
                                            mContext.startActivity(intent);
                                        }else{
                                            dialog.dismiss();
                                            AlertDialog.Builder builder = new AlertDialog.Builder(mContext,R.style.AlertDialogStyle);
                                            builder.setTitle(mContext.getString(R.string.job_deleted_title))
                                                    .setMessage(mContext.getString(R.string.job_deleted_applied_info))
                                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialog, int which) {

                                                        }
                                                    });
                                            AlertDialog alertDialog = builder.create();
                                            alertDialog.show();
                                        }
                                    }else{
                                        Toast.makeText(mContext, "Failed", Toast.LENGTH_SHORT).show();
                                        dialog.dismiss();
                                    }

                                }
                            });

                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });
    }

    @NonNull
    @Override
    public AppliedJobHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.applied_job_item,parent,false);
        return new AppliedJobHolder(v);
    }

    class AppliedJobHolder extends RecyclerView.ViewHolder{
        CardView applied_job_cardview;
        TextView applied_jobTitle, applied_jobDescription, applied_jobCategory, applied_jobLocation, applied_jobPostedDate,applied_jobAppliedDate;


        public AppliedJobHolder(@NonNull View itemView) {
            super(itemView);
            applied_job_cardview = (CardView)itemView.findViewById(R.id.applied_job_cardView);
            applied_jobTitle = (TextView)itemView.findViewById(R.id.text_applied_job_title);
            applied_jobDescription = (TextView)itemView.findViewById(R.id.text_applied_job_description);
            applied_jobCategory = (TextView)itemView.findViewById(R.id.text_applied_job_category);
            applied_jobLocation = (TextView)itemView.findViewById(R.id.text_applied_job_location);
            applied_jobPostedDate = (TextView)itemView.findViewById(R.id.text_applied_job_posted_date);
            applied_jobAppliedDate = (TextView)itemView.findViewById(R.id.text_applied_job_applied_date);

        }
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
