package com.example.jobseekers.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.AccountActivity.LoginActivity;
import com.example.jobseekers.Class.Job;
import com.example.jobseekers.JobDetails;
import com.example.jobseekers.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JobAdapter extends FirestoreRecyclerAdapter<Job,JobAdapter.JobHolder> {
    private Context mContext;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private String userID = user.getUid();

    public JobAdapter(Context context,@NonNull FirestoreRecyclerOptions<Job> options) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(final @NonNull JobHolder holder, int position, final @NonNull Job model) {
        holder.jobTitle.setText(model.getJobTitle());
        holder.jobDescription.setText(model.getJobDescription());
        holder.jobCategory.setText(model.getCategory());
        holder.jobPostedDate.setText(model.getCreatedIn());
        holder.jobLocation.setText(model.getLocation());
        holder.saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isNetworkAvailable(mContext)){
                    holder.saveBtn.setClickable(false);
                    if(user.isAnonymous()){
                        Intent intentLogin = new Intent(mContext, LoginActivity.class);
                        Toast.makeText(mContext, "Please Login!", Toast.LENGTH_SHORT).show();
                        mContext.startActivity(intentLogin);
                    }else{
                        LayoutInflater inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        View theView = inflater.inflate(R.layout.progress_dialog, null);
                        final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setCancelable(false); // if you want user to wait for some process to finish,
                        builder.setView(theView);
                        final AlertDialog dialog = builder.create();
                        dialog.show();

                        firebaseFirestore.collection("Users")
                                .document(userID)
                                .collection("SavedJob")
                                .document(model.getJobID())
                                .get()
                                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                        if(task.isSuccessful()){
                                            DocumentSnapshot document = task.getResult();
                                            if(document.exists()){
                                                Toast.makeText(mContext, "You Already Saved This Job", Toast.LENGTH_SHORT).show();
                                                holder.saveBtn.setClickable(true);
                                                dialog.dismiss();
                                            }else{
                                                Date c = Calendar.getInstance().getTime();
                                                System.out.println("Current time => " + c);
                                                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                String formattedDate = df.format(c);
                                                SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                String formattedDateQuery = dfdate.format(c);

                                                Map<Object, String> jobdata = new HashMap<>();
                                                Map<Object,Double>jobdataSalary = new HashMap<>();
                                                jobdata.put("JobID", model.getJobID());
                                                jobdata.put("JobTitle", model.getJobTitle());
                                                jobdata.put("JobDescription", model.getJobDescription());
                                                jobdata.put("JobType", model.getJobType());
                                                jobdata.put("Category", model.getCategory());
                                                jobdata.put("CompanyName", model.getCompanyName());
                                                jobdata.put("Location", model.getLocation());
                                                jobdata.put("Address", model.getAddress());
                                                jobdataSalary.put("Salary", model.getSalary());
                                                jobdata.put("Phone", model.getPhone());
                                                jobdata.put("Email", model.getEmail());
                                                jobdata.put("Qualification", model.getQualification());
                                                jobdata.put("PostedBy", model.getPostedBy());
                                                jobdata.put("CreatedIn", model.getCreatedIn());
                                                jobdata.put("SavedIn",formattedDate);
                                                jobdata.put("SavedInQuery",formattedDateQuery);
                                                
                                                firebaseFirestore.collection("Users")
                                                        .document(userID)
                                                        .collection("SavedJob")
                                                        .document(model.getJobID())
                                                        .set(jobdataSalary, SetOptions.merge())
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                holder.saveBtn.setClickable(true);
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                holder.saveBtn.setClickable(true);
                                                            }
                                                        });

                                                firebaseFirestore.collection("Users")
                                                        .document(userID)
                                                        .collection("SavedJob")
                                                        .document(model.getJobID())
                                                        .set(jobdata, SetOptions.merge())
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                holder.saveBtn.setClickable(true);
                                                                dialog.dismiss();
                                                                Toast.makeText(mContext, "Job Saved ", Toast.LENGTH_SHORT).show();
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                holder.saveBtn.setClickable(true);
                                                                dialog.dismiss();
                                                                Toast.makeText(mContext, "Failed To Save Job", Toast.LENGTH_SHORT).show();
                                                            }
                                                        });


                                            }
                                        }else{
                                            holder.saveBtn.setClickable(true);
                                            dialog.dismiss();
                                            Toast.makeText(mContext, "Failed", Toast.LENGTH_SHORT).show();
                                        }

                                    }
                                });
                    }

                }else{
                    holder.saveBtn.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });

        holder.job_cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.job_cardview.setClickable(false);
                if(isNetworkAvailable(mContext)) {
                    Intent intent = new Intent(mContext, JobDetails.class);
                    intent.putExtra("JobID", model.getJobID());
                    intent.putExtra("Category",model.getCategory());
                    mContext.startActivity(intent);
                    holder.job_cardview.setClickable(true);
                }else{
                    holder.job_cardview.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AlertDialogStyle);
                    builder.setTitle(mContext.getString(R.string.connection_error))
                            .setMessage(mContext.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });


    }

    @NonNull
    @Override
    public JobHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.job_item,parent,false);
        return new JobHolder(view);
    }

    class JobHolder extends RecyclerView.ViewHolder{
        CardView job_cardview;
        TextView jobTitle,jobDescription,jobCategory,jobLocation,jobPostedDate;
        Button saveBtn;


        public JobHolder(@NonNull View itemView) {
            super(itemView);

            job_cardview = (CardView)itemView.findViewById(R.id.job_cardView);
            jobTitle = (TextView) itemView.findViewById(R.id.text_job_title);
            jobDescription = (TextView) itemView.findViewById(R.id.text_job_description);
            jobCategory = (TextView) itemView.findViewById(R.id.text_job_category);
            jobLocation = (TextView) itemView.findViewById(R.id.text_job_location);
            jobPostedDate = (TextView) itemView.findViewById(R.id.text_job_posted_date);
            saveBtn = (Button)itemView.findViewById(R.id.btn_save_job);

        }
    }


    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}
