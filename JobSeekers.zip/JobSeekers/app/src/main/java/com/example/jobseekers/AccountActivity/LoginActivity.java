package com.example.jobseekers.AccountActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.jobseekers.HomePage;
import com.example.jobseekers.MainActivity;
import com.example.jobseekers.R;
import com.example.jobseekers.Term_Privacy.Privacy_Policy;
import com.example.jobseekers.Term_Privacy.TermOfUse;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class LoginActivity extends AppCompatActivity {
    private EditText inputEmail, inputPassword;
    private FirebaseAuth auth;
    private Button btnLogin;
    private TextView btnRegister;
    private TextView btnForgotPassword;
    private ProgressBar progressBar;
    private TextView errorMessage;
    private TextView showPassword;
    private ImageButton cancelButton;
    private TextView btnTermPrivacy;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        auth = FirebaseAuth.getInstance();
        inputEmail = (EditText) findViewById(R.id.hint_login_email);
        inputPassword = (EditText) findViewById(R.id.hint_login_password);
        btnLogin = (Button) findViewById(R.id.login_button);
        btnRegister = (TextView) findViewById(R.id.login_register_button);
        btnForgotPassword = (TextView) findViewById(R.id.forgot_password_button);
        progressBar = (ProgressBar) findViewById(R.id.loginProgressBar);
        errorMessage = (TextView) findViewById(R.id.login_ErrorMessage);
        showPassword = (TextView) findViewById(R.id.togglePassword_button);
        cancelButton = (ImageButton)findViewById(R.id.login_cancel_button);
        btnTermPrivacy = (TextView)findViewById(R.id.login_termPolicy_button);
        inputPassword.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);


        SpannableString ss= new SpannableString(getString(R.string.term_privacy));
        ClickableSpan termOfUse = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(LoginActivity.this, TermOfUse.class));
                progressBar.setVisibility(View.VISIBLE);
            }
        };
        ClickableSpan privacyPolicy = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(LoginActivity.this, Privacy_Policy.class));
                progressBar.setVisibility(View.VISIBLE);

            }
        };
        ss.setSpan(termOfUse,0,11, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(privacyPolicy,14,ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        btnTermPrivacy.setText(ss);
        btnTermPrivacy.setMovementMethod(LinkMovementMethod.getInstance());

        inputPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() == 0) {
                    showPassword.setVisibility(View.GONE);
                } else {
                    showPassword.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        showPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(showPassword.getText()==getString(R.string.show_password)){
                    showPassword.setText(getString(R.string.hide_password));
                    inputPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    inputPassword.setSelection(inputPassword.length());
                }else{
                    showPassword.setText(getString(R.string.show_password));
                    inputPassword.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    inputPassword.setSelection(inputPassword.length());
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
                progressBar.setVisibility(View.VISIBLE);
                btnRegister.setClickable(false);
                finish();
            }
        });
        btnForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, ResetPasswordActivity.class));
                progressBar.setVisibility(View.VISIBLE);
                btnForgotPassword.setClickable(false);
                finish();
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable(LoginActivity.this)) {
                    String email = inputEmail.getText().toString().trim();
                    String password = inputPassword.getText().toString().trim();

                    if (!validateEmail() | !validatePassword()) {
                        return;
                    }

                    progressBar.setVisibility(View.VISIBLE);
                    auth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        errorMessage.setVisibility(View.VISIBLE);
                                        progressBar.setVisibility(View.INVISIBLE);
                                        btnLogin.setClickable(true);
                                    } else {
                                        Intent intent = new Intent(LoginActivity.this, HomePage.class);
                                        startActivity(intent);
                                        finish();
                                    }

                                }
                            });

                } else {
                    btnLogin.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this, R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
                    btnLogin.setClickable(false);
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private boolean validateEmail() {
        String email = inputEmail.getText().toString().trim();
        if (email.isEmpty()) {
            inputEmail.setError("Field can't be empty");
            return false;
        } else if (!isEmailValid(email)) {
            inputEmail.setError("Please Enter Correct Email");
            return false;
        } else {
            inputEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String password = inputPassword.getText().toString().trim();
        if (password.isEmpty()) {
            inputPassword.setError("Field can't be empty!");
            return false;
        } else if (password.length() < 6) {
            inputPassword.setError("Password too short!");
            return false;
        } else {
            inputPassword.setError(null);
            return true;
        }
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
        btnLogin.setClickable(true);
        btnRegister.setClickable(true);
        btnForgotPassword.setClickable(true);
    }
}
