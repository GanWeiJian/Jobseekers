package com.example.jobseekers.JobDetailsFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.Adapter.JobAdapter;
import com.example.jobseekers.Class.Job;
import com.example.jobseekers.R;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class SimilarJobFragment extends Fragment {
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private CollectionReference jobRef = firebaseFirestore.collection("All Job");
    private RecyclerView recyclerView;
    private JobAdapter adapter;
    private String category;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_similar_job,container,false);
        Intent intent = getActivity().getIntent();
        String category = intent.getStringExtra("Category");
        String jobID = intent.getStringExtra("JobID");

        recyclerView = (RecyclerView)view.findViewById(R.id.rv_similar_job);
        Query query = jobRef.whereEqualTo("Category",category)
                .limit(5)
                .orderBy("CreatedIn", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<Job> options = new FirestoreRecyclerOptions.Builder<Job>()
                .setQuery(query,Job.class)
                .build();

        adapter = new JobAdapter(getActivity(),options);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onStart(){
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop(){
        super.onStop();
        adapter.stopListening();
    }
}
