package com.example.jobseekers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.os.Environment.DIRECTORY_DOWNLOADS;

public class UserDetailsActivity extends AppCompatActivity {
    private TextView Username,Email,Location,CareerFields,Name,emailTxt,phoneNo,locationTxt,Address,Experience;
    private CircleImageView profileholder;
    private FirebaseFirestore firebaseFirestore;
    private Button downloadResume,interviewBtn;
    private DownloadManager dm;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);
        firebaseFirestore = FirebaseFirestore.getInstance();

        Intent intent = getIntent();
        final String ID = intent.getStringExtra("UserID");
        final String resume = intent.getStringExtra("Resume");
        final String Fullname = intent.getStringExtra("Fullname");
        final String jobName = intent.getStringExtra("JobTitle");
        final String jobCompany = intent.getStringExtra("JobCompany");
        final String jobID = intent.getStringExtra("JobID");

        progressBar = (ProgressBar)findViewById(R.id.userDetailsProgress);
        Username = (TextView)findViewById(R.id.user_details_textUserName) ;
        Email = (TextView)findViewById(R.id.user_details_textUserEmail);
        Location = (TextView)findViewById(R.id.user_details_textUserLocation);
        CareerFields = (TextView)findViewById(R.id.user_details_textCareer);
        Name = (TextView)findViewById(R.id.user_details_profile_name);
        emailTxt = (TextView)findViewById(R.id.user_details_profile_email);
        phoneNo = (TextView)findViewById(R.id.user_details_phoneNo);
        locationTxt = (TextView)findViewById(R.id.user_details_profile_location);
        Address = (TextView)findViewById(R.id.user_details_profile_address);
        Experience = (TextView)findViewById(R.id.user_details_profile_experience);
        profileholder = (CircleImageView)findViewById(R.id.user_details_image_profile);
        downloadResume = (Button)findViewById(R.id.user_details_download_resume_btn);
        interviewBtn = (Button)findViewById(R.id.user_details_interview_btn);

        final Toolbar toolbar = findViewById(R.id.user_details_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        UserDetailsActivity.this.setTitle("User Details");

        interviewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                interviewBtn.setClickable(false);
                if(isNetworkAvailable(UserDetailsActivity.this)){
                    firebaseFirestore.collection("Users").document(ID).collection("Notification").document(jobID)
                            .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if(task.isSuccessful()){
                                final DocumentSnapshot document = task.getResult();
                                if(document.exists()){
                                    firebaseFirestore.collection("All Job").document(jobID).collection("AcceptedList").document(ID)
                                            .get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                        @Override
                                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                                            Intent intent = new Intent(UserDetailsActivity.this,InterviewDetails.class);
                                            String jobName = documentSnapshot.getString("JobName");
                                            String jobCompany = documentSnapshot.getString("JobCompany");
                                            String date = documentSnapshot.getString("InterviewDate");
                                            String time = documentSnapshot.getString("InterviewTime");
                                            String method = documentSnapshot.getString("Method");
                                            String place = documentSnapshot.getString("InterviewPlatform");
                                            String placeDetails = documentSnapshot.getString("InterviewPlatformDetails");
                                            String message = documentSnapshot.getString("InterviewMessage");

                                            intent.putExtra("jobName",jobName);
                                            intent.putExtra("jobCompany",jobCompany);
                                            intent.putExtra("date",date);
                                            intent.putExtra("time",time);
                                            intent.putExtra("method",method);
                                            intent.putExtra("place",place);
                                            intent.putExtra("placeDetails",placeDetails);
                                            intent.putExtra("message",message);
                                            interviewBtn.setClickable(true);
                                            progressBar.setVisibility(View.GONE);
                                            startActivity(intent);

                                        }
                                    });



                                }else{
                                    progressBar.setVisibility(View.GONE);
                                    interviewBtn.setClickable(true);
                                    Intent intent = new Intent(UserDetailsActivity.this,InterviewActivity.class);
                                    intent.putExtra("UserID",ID);
                                    intent.putExtra("JobID",jobID);
                                    intent.putExtra("JobTitle",jobName);
                                    intent.putExtra("JobCompany",jobCompany);
                                    startActivity(intent);
                                }
                            }else{
                                progressBar.setVisibility(View.GONE);
                                interviewBtn.setClickable(true);
                            }
                        }
                    });
                }else{
                    progressBar.setVisibility(View.GONE);
                    interviewBtn.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(UserDetailsActivity.this, R.style.AlertDialogStyle);
                    builder.setTitle(UserDetailsActivity.this.getString(R.string.connection_error))
                            .setMessage(UserDetailsActivity.this.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        downloadResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isNetworkAvailable(UserDetailsActivity.this)){
                    if(resume==null){
                        AlertDialog.Builder builder = new AlertDialog.Builder(UserDetailsActivity.this, R.style.AlertDialogStyle);
                        builder.setMessage("User Did Not Submit Resume!")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });

                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }else{
                        dm = (DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(resume));
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        request.setDestinationInExternalFilesDir(UserDetailsActivity.this,DIRECTORY_DOWNLOADS,"Resume:"+Fullname);
                        dm.enqueue(request);
                        Toast.makeText(UserDetailsActivity.this,"Downloading...",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(UserDetailsActivity.this, R.style.AlertDialogStyle);
                    builder.setTitle(UserDetailsActivity.this.getString(R.string.connection_error))
                            .setMessage(UserDetailsActivity.this.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });

        firebaseFirestore.collection("Users")
                .document(ID)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        String firstname = documentSnapshot.getString("FirstName");
                        String lastName = documentSnapshot.getString("LastName");
                        String email = documentSnapshot.getString("Email");
                        String PhoneNo = documentSnapshot.getString("PhoneNo");
                        String address = documentSnapshot.getString("Address");
                        String location = documentSnapshot.getString("Location");
                        String experience = documentSnapshot.getString("Experience");
                        String career = documentSnapshot.getString("CareerFields");
                        String profile_image_uri = documentSnapshot.getString("ProfilePicture");
                        String fullname = firstname +" "+lastName;

                        Username.setText(fullname);
                        Email.setText(email);
                        phoneNo.setText(PhoneNo);
                        Name.setText(fullname);
                        emailTxt.setText(email);
                        if(address==null){
                            Address.setText("Unknown");
                        }else{
                            Address.setText(address);
                        }


                        if(location==null){
                            Location.setText("Unknown");
                            locationTxt.setText("Unknown");
                        }else{
                            Location.setText(location);
                            locationTxt.setText(location);
                        }

                        if(experience==null){
                            Experience.setText("Unknown");
                        }else{
                            Experience.setText(experience);
                        }

                        if (career==null){
                            CareerFields.setText("Unknown");
                        }else{
                            CareerFields.setText(career);
                        }

                        if(profile_image_uri==null){

                        }else{
                            Picasso.get().load(profile_image_uri).into(profileholder);
                        }


                    }
                });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onResume(){
        super.onResume();
        interviewBtn.setClickable(true);

    }

}
