package com.example.jobseekers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobseekers.Drawer_Fragment.AddJobFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.santalu.maskedittext.MaskEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EditJob extends AppCompatActivity {
    private Spinner locationSpinner, categorySpinner, qualificationSpinner, jobTypeSpinner;
    private EditText edit_job_title, edit_job_description, edit_company_name, edit_address, edit_salary, edit_email;
    private MaskEditText edit_phoneNo;
    private Button edit_job_btn, cancel_job_btn;
    private String job_location, job_qualification, job_category, job_type;
    private ProgressBar editJobProgress;
    private String userID;
    private FirebaseUser user;
    private FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_job);
        firebaseFirestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();

        Intent intent = getIntent();
        final String jobID = intent.getStringExtra("JobID");
        String jobTitle = intent.getStringExtra("JobTitle");
        String jobDescription = intent.getStringExtra("Description");
        String companyName = intent.getStringExtra("Company");
        String address = intent.getStringExtra("Address");
        Double salary = intent.getDoubleExtra("Salary",0);
        String phone = intent.getStringExtra("Phone");
        String email = intent.getStringExtra("Email");

        Toolbar toolbar = findViewById(R.id.edit_job_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        EditJob.this.setTitle(getString(R.string.edit_title));

        edit_job_title = (EditText)findViewById(R.id.edit_edit_job_title);
        edit_job_description = (EditText)findViewById(R.id.edit_edit_job_description);
        edit_company_name = (EditText)findViewById(R.id.edit_edit_job_company);
        edit_address = (EditText) findViewById(R.id.edit_edit_job_address);
        edit_salary = (EditText) findViewById(R.id.edit_edit_job_salary);
        edit_phoneNo = (MaskEditText) findViewById(R.id.edit_edit_job_phone);
        edit_email = (EditText) findViewById(R.id.edit_edit_job_email);
        edit_job_btn = (Button) findViewById(R.id.edit_job_btn);
        cancel_job_btn = (Button) findViewById(R.id.edit_cancel_job_btn);
        editJobProgress = (ProgressBar) findViewById(R.id.edit_job_progressBar);

        edit_job_title.setText(jobTitle);
        edit_job_description.setText(jobDescription);
        edit_company_name.setText(companyName);
        edit_address.setText(address);
        edit_salary.setText(salary.toString());
        edit_phoneNo.setText(phone);
        edit_email.setText(email);

        jobTypeSpinner = (Spinner) findViewById(R.id.spEditJobType);
        locationSpinner = (Spinner) findViewById(R.id.spEditLocation);
        categorySpinner = (Spinner) findViewById(R.id.spEditCategory);
        qualificationSpinner = (Spinner) findViewById(R.id.spEditQualification);
        edit_salary.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(10,2)});

        ArrayAdapter<CharSequence> locationAdapter = ArrayAdapter.createFromResource(EditJob.this, R.array.edit_job_location_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(EditJob.this, R.array.edit_job_category_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> qualificationAdapter = ArrayAdapter.createFromResource(EditJob.this, R.array.edit_job_qualification_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> jobTypeAdapter = ArrayAdapter.createFromResource(EditJob.this, R.array.edit_job_job_type_list, android.R.layout.simple_spinner_item);

        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        qualificationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jobTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        locationSpinner.setAdapter(locationAdapter);
        categorySpinner.setAdapter(categoryAdapter);
        qualificationSpinner.setAdapter(qualificationAdapter);
        jobTypeSpinner.setAdapter(jobTypeAdapter);

        jobTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!jobTypeSpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Job Type")) {
                    job_type = parent.getItemAtPosition(position).toString();
                } else {
                    job_type = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        locationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!locationSpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Location")) {
                    job_location = parent.getItemAtPosition(position).toString();
                } else {
                    job_location = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!categorySpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Category")) {
                    job_category = parent.getItemAtPosition(position).toString();
                } else {
                    job_category = null;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        qualificationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!qualificationSpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Qualification")) {
                    job_qualification = parent.getItemAtPosition(position).toString();
                } else {
                    job_qualification = null;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        edit_job_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_job_btn.setClickable(false);
                if(isNetworkAvailable(EditJob.this)){
                    if (!validateEmail() | !validatePhoneNo() | !validateCategory() | !validateCompanyName() | !validateJobDescription() |
                            !validateJobTitle() | !validateSalary() | !validateQualification() | !validateAddress() | !validateLocation() | !validateJobType()) {
                        edit_job_btn.setClickable(true);
                        return;
                    }

                    Date c = Calendar.getInstance().getTime();
                    System.out.println("Current time => " + c);
                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    String formattedDate = df.format(c);

                    String new_jobDetails, new_jobDescription, new_companyName, new_address, new_phoneNo, new_email;
                    double new_salary;
                    new_jobDetails = edit_job_title.getText().toString().trim();
                    new_jobDescription = edit_job_description.getText().toString().trim();
                    new_companyName = edit_company_name.getText().toString().trim();
                    new_address = edit_address.getText().toString().trim();
                    //salary = edit_salary.getText().toString().trim();
                    new_salary = Double.parseDouble(edit_salary.getText().toString());
                    new_phoneNo = edit_phoneNo.getText().toString().trim();
                    new_email = edit_email.getText().toString().trim();

                    editJobProgress.setVisibility(View.VISIBLE);

                    Map<Object, String> jobdata = new HashMap<>();
                    Map<Object,Double>jobdataSalary = new HashMap<>();
                    jobdata.put("JobTitle", new_jobDetails);
                    jobdata.put("JobDescription", new_jobDescription);
                    jobdata.put("JobType", job_type);
                    jobdata.put("Category", job_category);
                    jobdata.put("CompanyName", new_companyName);
                    jobdata.put("Location", job_location);
                    jobdata.put("Address", new_address);
                    jobdataSalary.put("Salary", new_salary);
                    jobdata.put("Phone", new_phoneNo);
                    jobdata.put("Email", new_email);
                    jobdata.put("Qualification", job_qualification);
                    jobdata.put("CreatedIn", formattedDate);

                    firebaseFirestore.collection("All Job")
                            .document(jobID)
                            .set(jobdataSalary,SetOptions.merge())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });

                    firebaseFirestore.collection("All Job")
                            .document(jobID)
                            .set(jobdata,SetOptions.merge())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {

                                    edit_job_btn.setClickable(true);
                                    editJobProgress.setVisibility(View.GONE);
                                    Toast.makeText(EditJob.this, "Job Edit Successfully", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    editJobProgress.setVisibility(View.GONE);
                                    edit_job_btn.setClickable(true);
                                    Toast.makeText(EditJob.this, "Job Edit Failed", Toast.LENGTH_SHORT).show();
                                }
                            });

                    Map<Object, String> userdata = new HashMap<>();
                    Map<Object, Double> userdataSalary = new HashMap<>();
                    userdata.put("JobTitle", new_jobDetails);
                    userdata.put("JobDescription", new_jobDescription);
                    userdata.put("JobType", job_type);
                    userdata.put("Category", job_category);
                    userdata.put("CompanyName", new_companyName);
                    userdata.put("Location", job_location);
                    userdata.put("Address", new_address);
                    userdataSalary.put("Salary", new_salary);
                    userdata.put("Phone", new_phoneNo);
                    userdata.put("Email", new_email);
                    userdata.put("Qualification", job_qualification);
                    userdata.put("CreatedIn", formattedDate);
                    firebaseFirestore.collection("Users")
                            .document(userID)
                            .collection("PostedJob")
                            .document(jobID)
                            .set(userdataSalary,SetOptions.merge())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });

                    firebaseFirestore.collection("Users")
                            .document(userID)
                            .collection("PostedJob")
                            .document(jobID)
                            .set(userdata,SetOptions.merge())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    edit_job_btn.setClickable(true);
                                    editJobProgress.setVisibility(View.GONE);
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    editJobProgress.setVisibility(View.GONE);
                                    edit_job_btn.setClickable(true);
                                }
                            });

                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(EditJob.this, R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    edit_job_btn.setClickable(true);
                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                   edit_job_btn.setClickable(true);
                }
            }
        });

        cancel_job_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean validateJobTitle() {
        String jobTitle = edit_job_title.getText().toString().trim();
        if (jobTitle.isEmpty()) {
            edit_job_title.setError("Field can't be empty!");
            return false;
        } else {
            edit_job_title.setError(null);
            return true;
        }
    }

    private boolean validateJobDescription() {
        String jobDescription = edit_job_description.getText().toString().trim();
        if (jobDescription.isEmpty()) {
            edit_job_description.setError("Field can't be empty!");
            return false;
        } else {
            edit_job_description.setError(null);
            return true;
        }
    }

    private boolean validateJobType() {
        if (job_type == null) {
            ((TextView) jobTypeSpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateLocation() {
        if (job_location == null) {
            ((TextView) locationSpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateCategory() {
        if (job_category == null) {
            ((TextView) categorySpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateQualification() {
        if (job_qualification == null) {
            ((TextView) qualificationSpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateCompanyName() {
        String companyName = edit_company_name.getText().toString().trim();
        if (companyName.isEmpty()) {
            edit_company_name.setError("Field can't be empty!");
            return false;
        } else {
            edit_company_name.setError(null);
            return true;
        }
    }

    private boolean validateAddress() {
        String address = edit_address.getText().toString().trim();
        if (address.isEmpty()) {
            edit_address.setError("Field can't be empty!");
            return false;
        } else {
            edit_address.setError(null);
            return true;
        }
    }

    private boolean validateSalary() {
        double salary = 0;
        String salaryText = edit_salary.getText().toString().trim();
        if (!salaryText.isEmpty()) {
            salary = Double.parseDouble(edit_salary.getText().toString().trim());
        }
        if (salaryText.isEmpty()) {
            edit_salary.setError("Field can't be empty!");
            return false;
        }
        if (salary <= 0) {
            edit_salary.setError("Salary must be more than 0");
            return false;
        } else {
            edit_salary.setError(null);
            return true;
        }
    }

    private boolean validatePhoneNo() {
        String phoneNo = edit_phoneNo.getText().toString().trim();
        if (phoneNo.isEmpty()) {
            edit_phoneNo.setError("Field can't be empty!");
            return false;
        } else {
            edit_phoneNo.setError(null);
            return true;
        }
    }

    private boolean validateEmail() {
        String email = edit_email.getText().toString().trim();
        if (email.isEmpty()) {
            edit_email.setError("Field can't be empty");
            return false;
        } else if (!isEmailValid(email)) {
            edit_email.setError("Please Enter Correct Email");
            return false;
        } else {
            edit_email.setError(null);
            return true;
        }
    }

    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;

        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }
}
