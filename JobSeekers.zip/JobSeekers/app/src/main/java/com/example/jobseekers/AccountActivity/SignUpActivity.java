package com.example.jobseekers.AccountActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobseekers.HomePage;
import com.example.jobseekers.R;
import com.example.jobseekers.Term_Privacy.Privacy_Policy;
import com.example.jobseekers.Term_Privacy.TermOfUse;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.santalu.maskedittext.MaskEditText;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignUpActivity extends AppCompatActivity {

    private TextView btnTerm_privacy;
    private TextView btnLogin;
    private MaskEditText inputPhoneNo;
    private EditText inputEmail, inputPassword, inputFirstMame, inputLastName;
    private Button btnRegister;
    private ImageButton btnCancel;
    private ProgressBar progressBar;
    private FirebaseAuth auth;
    private DatabaseReference databaseReference;
    private FirebaseFirestore firebaseFirestore;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        //Get Firebase auth Instance
        auth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        firebaseFirestore = FirebaseFirestore.getInstance();
        btnLogin = (TextView) findViewById(R.id.register_login_button);
        btnCancel = (ImageButton) findViewById(R.id.register_cancel_button);
        inputEmail = (EditText) findViewById(R.id.register_email_text);
        inputPassword = (EditText) findViewById(R.id.register_password_text);
        inputFirstMame = (EditText) findViewById(R.id.register_firstName_text);
        inputLastName = (EditText) findViewById(R.id.register_lastName_text);
        inputPhoneNo = (MaskEditText) findViewById(R.id.register_phoneNo_text);
        btnTerm_privacy = (TextView) findViewById(R.id.register_term_privacy_button);

        btnRegister = (Button) findViewById(R.id.register_button);
        progressBar = (ProgressBar) findViewById(R.id.registerProgressBar);

        SpannableString ss = new SpannableString(getString(R.string.term_privacy));
        ClickableSpan termOfUse = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(SignUpActivity.this, TermOfUse.class));
                progressBar.setVisibility(View.VISIBLE);
            }
        };
        ClickableSpan privacyPolicy = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                startActivity(new Intent(SignUpActivity.this, Privacy_Policy.class));
                progressBar.setVisibility(View.VISIBLE);

            }
        };
        ss.setSpan(termOfUse, 0, 11, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(privacyPolicy, 14, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        btnTerm_privacy.setText(ss);
        btnTerm_privacy.setMovementMethod(LinkMovementMethod.getInstance());

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                progressBar.setVisibility(View.VISIBLE);
                btnLogin.setClickable(false);
                finish();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                finish();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable(SignUpActivity.this)) {
                    final String email = inputEmail.getText().toString().trim();
                    String password = inputPassword.getText().toString().trim();
                    final String firstName = inputFirstMame.getText().toString().trim();
                    final String lastName = inputLastName.getText().toString().trim();
                    final String phoneNo = inputPhoneNo.getText().toString().trim();

                    if (!validateEmail() | !validatePassword() | !validateFirstName() | !validateLastName() | !validatePhoneNo()) {
                        return;
                    }

                    progressBar.setVisibility(View.VISIBLE);
                    //create user
                    auth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        //Toast.makeText(SignUpActivity.this,"Create Account Failed!"+task.getException(),Toast.LENGTH_SHORT).show();
                                        progressBar.setVisibility(View.GONE);
                                        btnRegister.setClickable(true);
                                        inputEmail.setError("This Email Has Been Registered");
                                    } else {
                                        FirebaseUser users = FirebaseAuth.getInstance().getCurrentUser();
                                        String UserID = users.getUid();
                                        Map<Object, String> userdata = new HashMap<>();
                                        userdata.put("ID",UserID);
                                        userdata.put("Email",email);
                                        userdata.put("FirstName", firstName);
                                        userdata.put("LastName", lastName);
                                        userdata.put("PhoneNo", phoneNo);
                                        firebaseFirestore.collection("Users")
                                                .document(UserID)
                                                .set(userdata)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        startActivity(new Intent(SignUpActivity.this, HomePage.class));
                                                        finish();
                                                        Toast.makeText(SignUpActivity.this, "Account Register Successfully!", Toast.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        progressBar.setVisibility(View.INVISIBLE);
                                                        btnRegister.setClickable(true);
                                                        Toast.makeText(SignUpActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                    }
                                }
                            });
                } else {
                    //Toast.makeText(SignUpActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                    btnRegister.setClickable(true);
                    AlertDialog.Builder builder = new AlertDialog.Builder(SignUpActivity.this, R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }
                btnRegister.setClickable(false);
            }

        });
    }

    private boolean validateEmail() {
        String email = inputEmail.getText().toString().trim();
        if (email.isEmpty()) {
            inputEmail.setError("Field can't be empty");
            return false;
        } else if (!isEmailValid(email)) {
            inputEmail.setError("Please Enter Correct Email");
            return false;
        } else {
            inputEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String password = inputPassword.getText().toString().trim();
        if (password.isEmpty()) {
            inputPassword.setError("Field can't be empty!");
            return false;
        } else if (password.length() < 6) {
            inputPassword.setError("Password too short!");
            return false;
        } else {
            inputPassword.setError(null);
            return true;
        }
    }

    private boolean validateFirstName() {
        String firstName = inputFirstMame.getText().toString().trim();
        if (firstName.isEmpty()) {
            inputFirstMame.setError("Field can't be empty!");
            return false;
        } else {
            inputFirstMame.setError(null);
            return true;
        }

    }

    private boolean validateLastName() {
        String lastName = inputLastName.getText().toString().trim();
        if (lastName.isEmpty()) {
            inputLastName.setError("Field can't be empty!");
            return false;
        } else {
            inputLastName.setError(null);
            return true;
        }

    }

    private boolean validatePhoneNo() {
        String phoneNo = inputPhoneNo.getText().toString().trim();
        if (phoneNo.isEmpty()) {
            inputPhoneNo.setError("Field can't be empty!");
            return false;
        } else {
            inputPhoneNo.setError(null);
            return true;
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
        btnLogin.setClickable(true);
        btnRegister.setClickable(true);
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }


    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}
