package com.example.jobseekers.Drawer_Fragment;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.example.jobseekers.R;

import java.io.InputStream;

public class PrivacyPolicyFragment extends Fragment {
    private TextView privacy_policy;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_privacy_policy,container,false);
        privacy_policy = (TextView)view.findViewById(R.id.privacy_policy_in_fragment);
        try {
            Resources res = getResources();
            InputStream in_s = res.openRawResource(R.raw.privacy);
            byte[] b = new byte[in_s.available()];
            in_s.read(b);
            privacy_policy.setText(new String(b));
        } catch (Exception e) {
            privacy_policy.setText("Error: can't show terms.");
        }

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.privacy_policy));
    }


}
