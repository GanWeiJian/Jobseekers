package com.example.jobseekers.Drawer_Fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.jobseekers.BottomNav.HomeFragment;
import com.example.jobseekers.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.santalu.maskedittext.MaskEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddJobFragment extends Fragment {
    private Spinner locationSpinner, categorySpinner, qualificationSpinner, jobTypeSpinner;
    private EditText edit_job_title, edit_job_description, edit_company_name, edit_address, edit_salary, edit_email;
    private MaskEditText edit_phoneNo;
    private Button add_job_btn, cancel_job_btn;
    private String job_location, job_qualification, job_category, job_type;
    private ProgressBar addJobProgress;
    private String userID;
    private FirebaseUser user;
    private FirebaseFirestore firebaseFirestore;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_job, container, false);
        firebaseFirestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();

        edit_job_title = (EditText) view.findViewById(R.id.edit_add_job_title);
        edit_job_description = (EditText) view.findViewById(R.id.edit_add_job_description);
        edit_company_name = (EditText) view.findViewById(R.id.edit_add_job_company);
        edit_address = (EditText) view.findViewById(R.id.edit_add_job_address);
        edit_salary = (EditText) view.findViewById(R.id.edit_add_job_salary);
        edit_phoneNo = (MaskEditText) view.findViewById(R.id.edit_add_job_phone);
        edit_email = (EditText) view.findViewById(R.id.edit_add_job_email);
        add_job_btn = (Button) view.findViewById(R.id.add_job_btn);
        cancel_job_btn = (Button) view.findViewById(R.id.cancel_job_btn);
        addJobProgress = (ProgressBar) view.findViewById(R.id.add_job_progressBar);

        jobTypeSpinner = (Spinner) view.findViewById(R.id.spJobType);
        locationSpinner = (Spinner) view.findViewById(R.id.spLocation);
        categorySpinner = (Spinner) view.findViewById(R.id.spCategory);
        qualificationSpinner = (Spinner) view.findViewById(R.id.spQualification);
        edit_salary.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(10,2)});

        ArrayAdapter<CharSequence> locationAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.add_job_location_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.add_job_category_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> qualificationAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.add_job_qualification_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> jobTypeAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.add_job_job_type_list, android.R.layout.simple_spinner_item);

        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        qualificationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jobTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        locationSpinner.setAdapter(locationAdapter);
        categorySpinner.setAdapter(categoryAdapter);
        qualificationSpinner.setAdapter(qualificationAdapter);
        jobTypeSpinner.setAdapter(jobTypeAdapter);

        jobTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!jobTypeSpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Job Type")) {
                    job_type = parent.getItemAtPosition(position).toString();
                } else {
                    job_type = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        locationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!locationSpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Location")) {
                    job_location = parent.getItemAtPosition(position).toString();
                } else {
                    job_location = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!categorySpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Category")) {
                    job_category = parent.getItemAtPosition(position).toString();
                } else {
                    job_category = null;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        qualificationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!qualificationSpinner.getSelectedItem().toString().equalsIgnoreCase("Select A Qualification")) {
                    job_qualification = parent.getItemAtPosition(position).toString();
                } else {
                    job_qualification = null;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        add_job_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add_job_btn.setClickable(false);
                if (isNetworkAvailable(getActivity())) {
                    if (!validateEmail() | !validatePhoneNo() | !validateCategory() | !validateCompanyName() | !validateJobDescription() |
                            !validateJobTitle() | !validateSalary() | !validateQualification() | !validateAddress() | !validateLocation() | !validateJobType()) {
                        add_job_btn.setClickable(true);
                        return;
                    }

                    Date c = Calendar.getInstance().getTime();
                    System.out.println("Current time => " + c);
                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                    String formattedDate = df.format(c);
                    String formattedDateQuery = dfdate.format(c);

                    String jobID = UUID.randomUUID().toString();
                    String jobDetails, jobDescription, companyName, address, phoneNo, email;
                    double salary;
                    jobDetails = edit_job_title.getText().toString().trim();
                    jobDescription = edit_job_description.getText().toString().trim();
                    companyName = edit_company_name.getText().toString().trim();
                    address = edit_address.getText().toString().trim();
                    //salary = edit_salary.getText().toString().trim();
                    salary = Double.parseDouble(edit_salary.getText().toString());
                    phoneNo = edit_phoneNo.getText().toString().trim();
                    email = edit_email.getText().toString().trim();

                    addJobProgress.setVisibility(View.VISIBLE);

                    Map<Object, String> jobdata = new HashMap<>();
                    Map<Object,Double>jobdataSalary = new HashMap<>();
                    jobdata.put("JobID", jobID);
                    jobdata.put("JobTitle", jobDetails);
                    jobdata.put("JobDescription", jobDescription);
                    jobdata.put("JobType", job_type);
                    jobdata.put("Category", job_category);
                    jobdata.put("CompanyName", companyName);
                    jobdata.put("Location", job_location);
                    jobdata.put("Address", address);
                    jobdataSalary.put("Salary", salary);
                    jobdata.put("Phone", phoneNo);
                    jobdata.put("Email", email);
                    jobdata.put("Qualification", job_qualification);
                    jobdata.put("PostedBy", userID);
                    jobdata.put("CreatedIn", formattedDate);
                    jobdata.put("CreatedInQuery",formattedDateQuery);

                    firebaseFirestore.collection("All Job")
                            .document(jobID)
                            .set(jobdataSalary, SetOptions.merge())
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });

                    firebaseFirestore.collection("All Job")
                            .document(jobID)
                            .set(jobdata, SetOptions.merge())
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    addJobProgress.setVisibility(View.GONE);
                                    add_job_btn.setClickable(true);
                                    edit_job_title.getText().clear();
                                    edit_job_description.getText().clear();
                                    edit_company_name.getText().clear();
                                    edit_address.getText().clear();
                                    edit_salary.getText().clear();
                                    edit_phoneNo.getText().clear();
                                    edit_email.getText().clear();
                                    Toast.makeText(getActivity(), "Job Added Successfully", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    addJobProgress.setVisibility(View.GONE);
                                    add_job_btn.setClickable(true);
                                    Toast.makeText(getActivity(), "Failed To Add Job", Toast.LENGTH_SHORT).show();
                                }
                            });

                    Map<Object, String> userdata = new HashMap<>();
                    Map<Object, Double> userdataSalary = new HashMap<>();
                    userdata.put("JobID", jobID);
                    userdata.put("JobTitle", jobDetails);
                    userdata.put("JobDescription", jobDescription);
                    userdata.put("JobType", job_type);
                    userdata.put("Category", job_category);
                    userdata.put("CompanyName", companyName);
                    userdata.put("Location", job_location);
                    userdata.put("Address", address);
                    userdataSalary.put("Salary", salary);
                    userdata.put("Phone", phoneNo);
                    userdata.put("Email", email);
                    userdata.put("Qualification", job_qualification);
                    userdata.put("PostedBy", userID);
                    userdata.put("CreatedIn", formattedDate);
                    userdata.put("CreatedInQuery",formattedDateQuery);
                    firebaseFirestore.collection("Users")
                            .document(userID)
                            .collection("PostedJob")
                            .document(jobID)
                            .set(userdataSalary, SetOptions.merge())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });


                    firebaseFirestore.collection("Users")
                            .document(userID)
                            .collection("PostedJob")
                            .document(jobID)
                            .set(userdata, SetOptions.merge())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    addJobProgress.setVisibility(View.GONE);
                                    add_job_btn.setClickable(true);
                                    edit_job_title.getText().clear();
                                    edit_job_description.getText().clear();
                                    edit_company_name.getText().clear();
                                    edit_address.getText().clear();
                                    edit_salary.getText().clear();
                                    edit_phoneNo.getText().clear();
                                    edit_email.getText().clear();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    addJobProgress.setVisibility(View.GONE);
                                    add_job_btn.setClickable(true);
                                }
                            });

                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
                    builder.setTitle(getString(R.string.connection_error))
                            .setMessage(getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    add_job_btn.setClickable(true);
                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                    add_job_btn.setClickable(true);
                }
            }
        });

        cancel_job_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_job_title.getText().clear();
                edit_job_description.getText().clear();
                edit_company_name.getText().clear();
                edit_address.getText().clear();
                edit_salary.getText().clear();
                edit_phoneNo.getText().clear();
                edit_email.getText().clear();
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.add_job));
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean validateJobTitle() {
        String jobTitle = edit_job_title.getText().toString().trim();
        if (jobTitle.isEmpty()) {
            edit_job_title.setError("Field can't be empty!");
            return false;
        } else {
            edit_job_title.setError(null);
            return true;
        }
    }

    private boolean validateJobDescription() {
        String jobDescription = edit_job_description.getText().toString().trim();
        if (jobDescription.isEmpty()) {
            edit_job_description.setError("Field can't be empty!");
            return false;
        } else {
            edit_job_description.setError(null);
            return true;
        }
    }

    private boolean validateJobType() {
        if (job_type == null) {
            ((TextView) jobTypeSpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateLocation() {
        if (job_location == null) {
            ((TextView) locationSpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateCategory() {
        if (job_category == null) {
            ((TextView) categorySpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateQualification() {
        if (job_qualification == null) {
            ((TextView) qualificationSpinner.getSelectedView()).setError("Error message");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateCompanyName() {
        String companyName = edit_company_name.getText().toString().trim();
        if (companyName.isEmpty()) {
            edit_company_name.setError("Field can't be empty!");
            return false;
        } else {
            edit_company_name.setError(null);
            return true;
        }
    }

    private boolean validateAddress() {
        String address = edit_address.getText().toString().trim();
        if (address.isEmpty()) {
            edit_address.setError("Field can't be empty!");
            return false;
        } else {
            edit_address.setError(null);
            return true;
        }
    }

    private boolean validateSalary() {
        double salary = 0;
        String salaryText = edit_salary.getText().toString().trim();
        if (!salaryText.isEmpty()) {
            salary = Double.parseDouble(edit_salary.getText().toString().trim());
        }
        if (salaryText.isEmpty()) {
            edit_salary.setError("Field can't be empty!");
            return false;
        }
        if (salary <= 0) {
            edit_salary.setError("Salary must be more than 0");
            return false;
        } else {
            edit_salary.setError(null);
            return true;
        }
    }

    private boolean validatePhoneNo() {
        String phoneNo = edit_phoneNo.getText().toString().trim();
        if (phoneNo.isEmpty()) {
            edit_phoneNo.setError("Field can't be empty!");
            return false;
        } else {
            edit_phoneNo.setError(null);
            return true;
        }
    }

    private boolean validateEmail() {
        String email = edit_email.getText().toString().trim();
        if (email.isEmpty()) {
            edit_email.setError("Field can't be empty");
            return false;
        } else if (!isEmailValid(email)) {
            edit_email.setError("Please Enter Correct Email");
            return false;
        } else {
            edit_email.setError(null);
            return true;
        }
    }

    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;

        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }



}
