package com.example.jobseekers.Drawer_Fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.jobseekers.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class FeedbackFragment extends Fragment {
    private EditText feedback_name, feedback_phone, feedback_email, feedback_details, feedback_bug;
    private String userID;
    private String[] list;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseUser user;
    private Button submit_btn;
    private int position;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_feedback, container, false);
        firebaseFirestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();

        submit_btn = (Button) view.findViewById(R.id.feedback_submit_btn);
        feedback_bug = (EditText) view.findViewById(R.id.feedback_bug);
        feedback_name = (EditText) view.findViewById(R.id.feedback_name);
        feedback_phone = (EditText) view.findViewById(R.id.feedback_phone);
        feedback_email = (EditText) view.findViewById(R.id.feedback_email);
        feedback_details = (EditText) view.findViewById(R.id.feedback_details);

        position = 0;
        list = getActivity().getResources().getStringArray(R.array.bug_items);
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.MaterialThemeDialog);
        builder.setTitle(getString(R.string.feedback_report_bug))
                .setSingleChoiceItems(list, position, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        position = which;
                        feedback_bug.setText(list[which]);
                        dialog.dismiss();
                    }
                });


        feedback_bug.setFocusable(false);
        feedback_bug.setClickable(true);
        feedback_name.setFocusable(false);
        feedback_name.setClickable(false);
        feedback_phone.setFocusable(false);
        feedback_phone.setClickable(false);
        feedback_email.setFocusable(false);
        feedback_email.setClickable(false);

        feedback_bug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        firebaseFirestore.collection("Users").document(userID).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (!user.isAnonymous()) {
                    String user_FirstName = documentSnapshot.getString("FirstName");
                    String user_LastName = documentSnapshot.getString("LastName");
                    String user_PhoneNo = documentSnapshot.getString("PhoneNo");
                    String Fullname = user_FirstName + " " + user_LastName;

                    String email = user.getEmail();
                    feedback_name.setText(Fullname);
                    feedback_phone.setText(user_PhoneNo);
                    feedback_email.setText(email);

                } else {

                }
            }
        });

        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(feedback_bug.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(),R.style.AlertDialogStyle)
                            .setMessage(R.string.select_bug)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }else if(feedback_details.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(),R.style.AlertDialogStyle)
                            .setMessage(R.string.empty_details)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                } else {
                    sendMail();
                }
            }
        });
        return view;
    }

    private void sendMail() {
        String recipientList = getString(R.string.jobSeekers_email);
        String[] recipients = recipientList.split(",");
        String sender = feedback_email.getText().toString();
        String username = feedback_name.getText().toString();
        String subject = feedback_bug.getText().toString();
        String phone = feedback_phone.getText().toString();
        String details = feedback_details.getText().toString();

        String fullMessage = "Username: "+ username
                +"\nEmail: "+  sender
                +"\nPhone Number:"+ phone + "\n\n\n" + details;
        /*
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, recipients);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, fullMessage);
        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "Choose an email client"));*/

        Uri uri = Uri.parse("mailto:"+getString(R.string.jobSeekers_email));
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, fullMessage);
        startActivity(intent);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(getString(R.string.help_feedback));
    }

}
