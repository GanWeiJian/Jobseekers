package com.example.jobseekers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.jobseekers.Adapter.JobAdapter;
import com.example.jobseekers.Class.Job;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class FilterJob extends AppCompatActivity {
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private CollectionReference jobRef = firebaseFirestore.collection("All Job");
    private RecyclerView recyclerView;
    private JobAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter_job);
        Intent intent = getIntent();
        String category = intent.getStringExtra("Category");
        String location = intent.getStringExtra("Location");
        String jobType = intent.getStringExtra("JobType");
        double salary = intent.getDoubleExtra("Salary", 0);
        String qualification = intent.getStringExtra("Qualification");

        Toolbar toolbar = findViewById(R.id.filter_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        FilterJob.this.setTitle(getString(R.string.filter_page));


        recyclerView = (RecyclerView) findViewById(R.id.rv_filtered_job);
        Query query = jobRef.whereGreaterThanOrEqualTo("Salary", salary)
                .whereEqualTo("Category", category)
                .whereEqualTo("JobType", jobType)
                .whereEqualTo("Location", location)
                .whereEqualTo("Qualification", qualification)
                .orderBy("Salary", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<Job> options = new FirestoreRecyclerOptions.Builder<Job>()
                .setQuery(query, Job.class)
                .build();


        adapter = new JobAdapter(FilterJob.this, options);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(FilterJob.this));
        recyclerView.setAdapter(adapter);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
