package com.example.jobseekers.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobseekers.Class.Notification;
import com.example.jobseekers.InterviewActivity;
import com.example.jobseekers.InterviewDetails;
import com.example.jobseekers.R;
import com.example.jobseekers.UserDetailsActivity;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class NotificationAdapter extends FirestoreRecyclerAdapter<Notification, NotificationAdapter.NotificationHolder> {
    private Context context;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    public NotificationAdapter(Context context,@NonNull FirestoreRecyclerOptions<Notification> options) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull NotificationHolder holder, int position,final @NonNull Notification model) {
        holder.companyName.setText(model.getJobCompany());
        holder.notificationDate.setText(model.getInterviewAcceptedDate());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isNetworkAvailable(context)){
                    firebaseFirestore.collection("Users").document(user.getUid()).collection("Notification").document(model.getJobID())
                            .get()
                            .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                            Intent intent = new Intent(context, InterviewDetails.class);
                                            String jobName = documentSnapshot.getString("JobName");
                                            String jobCompany = documentSnapshot.getString("JobCompany");
                                            String date = documentSnapshot.getString("InterviewDate");
                                            String time = documentSnapshot.getString("InterviewTime");
                                            String method = documentSnapshot.getString("Method");
                                            String place = documentSnapshot.getString("InterviewPlatform");
                                            String placeDetails = documentSnapshot.getString("InterviewPlatformDetails");
                                            String message = documentSnapshot.getString("InterviewMessage");

                                            intent.putExtra("jobName",jobName);
                                            intent.putExtra("jobCompany",jobCompany);
                                            intent.putExtra("date",date);
                                            intent.putExtra("time",time);
                                            intent.putExtra("method",method);
                                            intent.putExtra("place",place);
                                            intent.putExtra("placeDetails",placeDetails);
                                            intent.putExtra("message",message);
                                            context.startActivity(intent);
                                }
                            });
                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AlertDialogStyle);
                    builder.setTitle(context.getString(R.string.connection_error))
                            .setMessage(context.getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });
    }

    @NonNull
    @Override
    public NotificationHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_item,parent,false);
        return new NotificationHolder(view);
    }

    class NotificationHolder extends RecyclerView.ViewHolder{
        TextView companyName,notificationDate;
        CardView cardView;

        public NotificationHolder(@NonNull View itemView) {
            super(itemView);
            companyName = (TextView)itemView.findViewById(R.id.notification_job_company);
            notificationDate = (TextView)itemView.findViewById(R.id.notification_date);
            cardView = (CardView)itemView.findViewById(R.id.notification_cardView);
        }
    }
    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
