package com.example.jobseekers.Term_Privacy;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.jobseekers.R;

import java.io.InputStream;

public class TermOfUse extends AppCompatActivity {

    private TextView term_of_use;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_of_use);
        Toolbar toolbar = findViewById(R.id.toolbar_terms);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        term_of_use = (TextView)findViewById(R.id.term_of_use);


        try {
            Resources res = getResources();
            InputStream in_s = res.openRawResource(R.raw.term);
            byte[] b = new byte[in_s.available()];
            in_s.read(b);
            term_of_use.setText(new String(b));
        } catch (Exception e) {
            term_of_use.setText("Error: can't show terms.");
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
