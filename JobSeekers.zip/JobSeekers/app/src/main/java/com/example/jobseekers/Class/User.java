package com.example.jobseekers.Class;

public class User {
    private String ID,FirstName,LastName,Location,PhoneNo,ProfilePicture,Resume,Address,CareerFields,Experience;

    public User(){

    }

    public User(String ID,String firstname, String lastname, String location, String phoneNo,String profilePicture,String resume,String address,String careerFields,String experience){
        this.ID = ID;
        this.FirstName = firstname;
        this.LastName = lastname;
        this.Location = location;
        this.PhoneNo = phoneNo;
        this.ProfilePicture = profilePicture;
        this.Resume = resume;
        this.Address = address;
        this.CareerFields = careerFields;
        this.Experience = experience;
    }

    public String getID() {
        return ID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getLocation() {
        return Location;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public String getProfilePicture() {
        return ProfilePicture;
    }

    public String getResume() {
        return Resume;
    }

    public String getAddress() {
        return Address;
    }

    public String getCareerFields() {
        return CareerFields;
    }

    public String getExperience() {
        return Experience;
    }
}
