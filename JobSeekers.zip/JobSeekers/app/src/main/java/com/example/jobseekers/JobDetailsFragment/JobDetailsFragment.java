package com.example.jobseekers.JobDetailsFragment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.jobseekers.AccountActivity.LoginActivity;
import com.example.jobseekers.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JobDetailsFragment extends Fragment {
    private TextView jobDescriptionTxt, salaryTxt, qualificationTxt;
    private Button bookmarkBtn, applyButton;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String userID = user.getUid();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final String jobID = getActivity().getIntent().getStringExtra("JobID");
        View view = inflater.inflate(R.layout.fragment_job_details, container, false);
        firebaseFirestore = FirebaseFirestore.getInstance();
        jobDescriptionTxt = (TextView) view.findViewById(R.id.job_details_description);
        salaryTxt = (TextView) view.findViewById(R.id.job_details_salary);
        qualificationTxt = (TextView) view.findViewById(R.id.job_details_qualification);
        bookmarkBtn = (Button) view.findViewById(R.id.job_details_bookmarkBtn);
        applyButton = (Button) view.findViewById(R.id.job_details_applyBtn);


        firebaseFirestore.collection("All Job").document(jobID).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String jobDescription = documentSnapshot.getString("JobDescription");
                Double salary = documentSnapshot.getDouble("Salary");
                String qualification = documentSnapshot.getString("Qualification");

                jobDescriptionTxt.setText(jobDescription);
                salaryTxt.setText("RM" + salary);
                qualificationTxt.setText(qualification);
            }
        });


        applyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getActivity(), "Job Apply Successfully", Toast.LENGTH_SHORT).show();
                if (isNetworkAvailable(getActivity())) {
                    applyButton.setClickable(false);
                    if (user.isAnonymous()) {
                        Intent intentLogin = new Intent(getActivity(), LoginActivity.class);
                        Toast.makeText(getActivity(), "Please Login !", Toast.LENGTH_SHORT).show();
                        startActivity(intentLogin);
                        getActivity().finish();
                        applyButton.setClickable(true);
                    } else {
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View theView = inflater.inflate(R.layout.progress_dialog, null);
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setCancelable(false); // if you want user to wait for some process to finish,
                        builder.setView(theView);
                        final AlertDialog dialog = builder.create();
                        dialog.show();

                        firebaseFirestore.collection("Users")
                                .document(userID)
                                .collection("AppliedJob")
                                .document(jobID)
                                .get()
                                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                        if (task.isSuccessful()) {
                                            final DocumentSnapshot document = task.getResult();
                                            if (document.exists()) {
                                                Toast.makeText(getActivity(), "You Already Applied This Job", Toast.LENGTH_SHORT).show();
                                                applyButton.setClickable(true);
                                                dialog.dismiss();
                                            } else {
                                                firebaseFirestore.collection("Users")
                                                        .document(userID)
                                                        .get()
                                                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                                            @Override
                                                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                                                Date c = Calendar.getInstance().getTime();
                                                                System.out.println("Current time => " + c);
                                                                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                                String formattedDate = df.format(c);
                                                                SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                                String formattedDateQuery = dfdate.format(c);

                                                                String firstname = documentSnapshot.getString("FirstName");
                                                                String lastname = documentSnapshot.getString("LastName");
                                                                String address = documentSnapshot.getString("Address");
                                                                String careerFields = documentSnapshot.getString("CareerFields");
                                                                String experience = documentSnapshot.getString("Experience");
                                                                String location = documentSnapshot.getString("Location");
                                                                String phoneNo = documentSnapshot.getString("PhoneNo");
                                                                String profilePic = documentSnapshot.getString("ProfilePicture");
                                                                String resume = documentSnapshot.getString("Resume");
                                                                String uid = userID;
                                                                Map<Object, String> userdata = new HashMap<>();
                                                                userdata.put("FirstName", firstname);
                                                                userdata.put("LastName", lastname);
                                                                userdata.put("Address", address);
                                                                userdata.put("CareerFields", careerFields);
                                                                userdata.put("Experience", experience);
                                                                userdata.put("Location", location);
                                                                userdata.put("PhoneNo", phoneNo);
                                                                userdata.put("ProfilePicture", profilePic);
                                                                userdata.put("Resume", resume);
                                                                userdata.put("ID", uid);
                                                                userdata.put("AppliedIn",formattedDate);
                                                                userdata.put("AppliedInQuery",formattedDateQuery);
                                                                firebaseFirestore.collection("All Job")
                                                                        .document(jobID)
                                                                        .collection("AppliedBy")
                                                                        .document(userID)
                                                                        .set(userdata, SetOptions.merge())
                                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                            @Override
                                                                            public void onSuccess(Void aVoid) {
                                                                                applyButton.setClickable(true);
                                                                                dialog.dismiss();
                                                                            }
                                                                        })
                                                                        .addOnFailureListener(new OnFailureListener() {
                                                                            @Override
                                                                            public void onFailure(@NonNull Exception e) {
                                                                                applyButton.setClickable(true);
                                                                                dialog.dismiss();
                                                                            }
                                                                        });

                                                            }
                                                        }).addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        applyButton.setClickable(true);
                                                        dialog.dismiss();
                                                    }
                                                });

                                                firebaseFirestore.collection("All Job")
                                                        .document(jobID)
                                                        .get()
                                                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                                            @Override
                                                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                                                Date c = Calendar.getInstance().getTime();
                                                                System.out.println("Current time => " + c);
                                                                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                                String formattedDate = df.format(c);
                                                                SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                                String formattedDateQuery = dfdate.format(c);

                                                                String jobID = documentSnapshot.getString("JobID");
                                                                String jobTitle = documentSnapshot.getString("JobTitle");
                                                                String jobDescription = documentSnapshot.getString("JobDescription");
                                                                String jobType = documentSnapshot.getString("JobType");
                                                                String category = documentSnapshot.getString("Category");
                                                                String companyName = documentSnapshot.getString("CompanyName");
                                                                String location = documentSnapshot.getString("Location");
                                                                String address = documentSnapshot.getString("Address");
                                                                Double salary = documentSnapshot.getDouble("Salary");
                                                                String phone = documentSnapshot.getString("Phone");
                                                                String email = documentSnapshot.getString("Email");
                                                                String qualification = documentSnapshot.getString("Qualification");
                                                                String postedDate = documentSnapshot.getString("CreatedIn");
                                                                String postedBy = documentSnapshot.getString("PostedBy");

                                                                Map<Object, String> jobdata = new HashMap<>();
                                                                Map<Object, Double> jobdataSalary = new HashMap<>();
                                                                jobdata.put("JobID", jobID);
                                                                jobdata.put("JobTitle", jobTitle);
                                                                jobdata.put("JobDescription", jobDescription);
                                                                jobdata.put("JobType", jobType);
                                                                jobdata.put("Category", category);
                                                                jobdata.put("CompanyName", companyName);
                                                                jobdata.put("Location", location);
                                                                jobdata.put("Address", address);
                                                                jobdataSalary.put("Salary", salary);
                                                                jobdata.put("Phone", phone);
                                                                jobdata.put("Email", email);
                                                                jobdata.put("Qualification", qualification);
                                                                jobdata.put("PostedBy", postedBy);
                                                                jobdata.put("CreatedIn", postedDate);
                                                                jobdata.put("AppliedIn", formattedDate);
                                                                jobdata.put("AppliedInQuery",formattedDateQuery);

                                                                firebaseFirestore.collection("Users")
                                                                        .document(userID)
                                                                        .collection("AppliedJob")
                                                                        .document(jobID)
                                                                        .set(jobdataSalary, SetOptions.merge())
                                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                                applyButton.setClickable(true);
                                                                            }
                                                                        })
                                                                        .addOnFailureListener(new OnFailureListener() {
                                                                            @Override
                                                                            public void onFailure(@NonNull Exception e) {
                                                                                applyButton.setClickable(true);
                                                                            }
                                                                        });

                                                                firebaseFirestore.collection("Users")
                                                                        .document(userID)
                                                                        .collection("AppliedJob")
                                                                        .document(jobID)
                                                                        .set(jobdata, SetOptions.merge())
                                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                                applyButton.setClickable(true);
                                                                                dialog.dismiss();
                                                                                Toast.makeText(getActivity(), "Job Applied Successfully", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        })
                                                                        .addOnFailureListener(new OnFailureListener() {
                                                                            @Override
                                                                            public void onFailure(@NonNull Exception e) {
                                                                                applyButton.setClickable(true);
                                                                                dialog.dismiss();
                                                                                Toast.makeText(getActivity(), "Failed To Apply Job", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        });


                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                applyButton.setClickable(true);
                                                                dialog.dismiss();
                                                            }
                                                        });

                                            }
                                        } else {
                                            bookmarkBtn.setClickable(true);
                                            dialog.dismiss();
                                            Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });


                    }
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
                    builder.setTitle(getActivity().getString(R.string.connection_error))
                            .setMessage(getActivity().getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });


        bookmarkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable(getActivity())) {
                    bookmarkBtn.setClickable(false);
                    if (user.isAnonymous()) {
                        Intent intentLogin = new Intent(getActivity(), LoginActivity.class);
                        Toast.makeText(getActivity(), "Please Login !", Toast.LENGTH_SHORT).show();
                        startActivity(intentLogin);
                        getActivity().finish();
                    } else {
                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View theView = inflater.inflate(R.layout.progress_dialog, null);
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setCancelable(false); // if you want user to wait for some process to finish,
                        builder.setView(theView);
                        final AlertDialog dialog = builder.create();
                        dialog.show();

                        firebaseFirestore.collection("Users")
                                .document(userID)
                                .collection("SavedJob")
                                .document(jobID)
                                .get()
                                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                        if (task.isSuccessful()) {
                                            final DocumentSnapshot document = task.getResult();
                                            if (document.exists()) {
                                                Toast.makeText(getActivity(), "You Already Saved This Job", Toast.LENGTH_SHORT).show();
                                                bookmarkBtn.setClickable(true);
                                                dialog.dismiss();
                                            } else {
                                                firebaseFirestore.collection("All Job")
                                                        .document(jobID)
                                                        .get()
                                                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                                            @Override
                                                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                                                Date c = Calendar.getInstance().getTime();
                                                                System.out.println("Current time => " + c);
                                                                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                                String formattedDate = df.format(c);
                                                                SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                                String formattedDateQuery = dfdate.format(c);

                                                                String jobID = documentSnapshot.getString("JobID");
                                                                String jobTitle = documentSnapshot.getString("JobTitle");
                                                                String jobDescription = documentSnapshot.getString("JobDescription");
                                                                String jobType = documentSnapshot.getString("JobType");
                                                                String category = documentSnapshot.getString("Category");
                                                                String companyName = documentSnapshot.getString("CompanyName");
                                                                String location = documentSnapshot.getString("Location");
                                                                String address = documentSnapshot.getString("Address");
                                                                Double salary = documentSnapshot.getDouble("Salary");
                                                                String phone = documentSnapshot.getString("Phone");
                                                                String email = documentSnapshot.getString("Email");
                                                                String qualification = documentSnapshot.getString("Qualification");
                                                                String postedDate = documentSnapshot.getString("CreatedIn");
                                                                String postedBy = documentSnapshot.getString("PostedBy");

                                                                Map<Object, String> jobdata = new HashMap<>();
                                                                Map<Object, Double> jobdataSalary = new HashMap<>();
                                                                jobdata.put("JobID", jobID);
                                                                jobdata.put("JobTitle", jobTitle);
                                                                jobdata.put("JobDescription", jobDescription);
                                                                jobdata.put("JobType", jobType);
                                                                jobdata.put("Category", category);
                                                                jobdata.put("CompanyName", companyName);
                                                                jobdata.put("Location", location);
                                                                jobdata.put("Address", address);
                                                                jobdataSalary.put("Salary", salary);
                                                                jobdata.put("Phone", phone);
                                                                jobdata.put("Email", email);
                                                                jobdata.put("Qualification", qualification);
                                                                jobdata.put("PostedBy", postedBy);
                                                                jobdata.put("CreatedIn", postedDate);
                                                                jobdata.put("SavedIn", formattedDate);
                                                                jobdata.put("SavedInQuery",formattedDateQuery);

                                                                firebaseFirestore.collection("Users")
                                                                        .document(userID)
                                                                        .collection("SavedJob")
                                                                        .document(jobID)
                                                                        .set(jobdataSalary, SetOptions.merge())
                                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                                bookmarkBtn.setClickable(true);
                                                                            }
                                                                        })
                                                                        .addOnFailureListener(new OnFailureListener() {
                                                                            @Override
                                                                            public void onFailure(@NonNull Exception e) {
                                                                                bookmarkBtn.setClickable(true);
                                                                            }
                                                                        });

                                                                firebaseFirestore.collection("Users")
                                                                        .document(userID)
                                                                        .collection("SavedJob")
                                                                        .document(jobID)
                                                                        .set(jobdata, SetOptions.merge())
                                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                                bookmarkBtn.setClickable(true);
                                                                                dialog.dismiss();
                                                                                Toast.makeText(getActivity(), "Job Saved ", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        })
                                                                        .addOnFailureListener(new OnFailureListener() {
                                                                            @Override
                                                                            public void onFailure(@NonNull Exception e) {
                                                                                bookmarkBtn.setClickable(true);
                                                                                dialog.dismiss();
                                                                                Toast.makeText(getActivity(), "Failed To Save Job", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        });


                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                bookmarkBtn.setClickable(true);
                                                            }
                                                        });


                                            }
                                        } else {
                                            bookmarkBtn.setClickable(true);
                                            dialog.dismiss();
                                            Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                                        }

                                    }
                                });

                    }
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
                    builder.setTitle(getActivity().getString(R.string.connection_error))
                            .setMessage(getActivity().getString(R.string.error_description))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });

        return view;
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
