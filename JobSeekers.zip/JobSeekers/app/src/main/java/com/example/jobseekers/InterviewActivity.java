package com.example.jobseekers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.santalu.maskedittext.MaskEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InterviewActivity extends AppCompatActivity {

    private LinearLayout online_interview_layout, face_to_face_interview_layout;
    private LinearLayout facebookLayout, wechat_layout, whatsapp_layout;
    private RadioGroup radioGroup;
    private Spinner spLocation, spPlatform;
    private EditText face_date, face_time, face_address, face_message;
    private EditText online_date, online_time, online_platform_facebook, online_platform_wechat, online_message;
    private MaskEditText online_platform_whatsapp;
    private Button submitBtn;
    private NumberPicker hourPicker, minPicker;
    private ProgressBar progressBar;
    private FirebaseFirestore firebaseFirestore;
    private String location;
    private String platformDetails;
    private FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interview);

        Intent intent = getIntent();
        final String companyName = intent.getStringExtra("JobCompany");
        final String jobName = intent.getStringExtra("JobTitle");
        final String ID = intent.getStringExtra("UserID");
        final String jobID = intent.getStringExtra("JobID");

        firebaseFirestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();

        online_interview_layout = (LinearLayout) findViewById(R.id.layout_online_interview);
        face_to_face_interview_layout = (LinearLayout) findViewById(R.id.layout_face_to_face_interview);
        facebookLayout = (LinearLayout) findViewById(R.id.facebook_layout);
        wechat_layout = (LinearLayout) findViewById(R.id.wechat_layout);
        whatsapp_layout = (LinearLayout) findViewById(R.id.whatsapp_layout);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        spLocation = (Spinner) findViewById(R.id.spInterviewLocation);
        spPlatform = (Spinner) findViewById(R.id.spInterviewPlatform);
        submitBtn = (Button) findViewById(R.id.interview_submit);
        progressBar = (ProgressBar) findViewById(R.id.interview_progressBar);

        online_date = (EditText) findViewById(R.id.interview_online_date);
        online_date.setFocusable(false);
        online_date.setClickable(true);
        online_time = (EditText) findViewById(R.id.interview_online_time);
        online_time.setFocusable(false);
        online_time.setClickable(true);
        online_platform_facebook = (EditText) findViewById(R.id.interview_online_fb_link);
        online_platform_wechat = (EditText) findViewById(R.id.interview_online_wechat);
        online_platform_whatsapp = (MaskEditText) findViewById(R.id.interview_online_whatsapp);
        online_message = (EditText) findViewById(R.id.interview_online_message);


        face_date = (EditText) findViewById(R.id.interview_face_interview_date);
        face_date.setFocusable(false);
        face_date.setClickable(true);
        face_time = (EditText) findViewById(R.id.interview_face_interview_time);
        face_time.setFocusable(false);
        face_time.setClickable(true);
        face_address = (EditText) findViewById(R.id.interview_face_interview_address);
        face_message = (EditText) findViewById(R.id.interview_face_interview_message);

        ArrayAdapter<CharSequence> locationAdapter = ArrayAdapter.createFromResource(InterviewActivity.this, R.array.interview_location_list, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> platformAdapter = ArrayAdapter.createFromResource(InterviewActivity.this, R.array.interview_platform_list, android.R.layout.simple_spinner_item);

        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        platformAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spLocation.setAdapter(locationAdapter);
        spLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                location = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spPlatform.setAdapter(platformAdapter);
        spPlatform.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getItemAtPosition(position).toString().equals("Facebook")) {
                    facebookLayout.setVisibility(View.VISIBLE);
                    whatsapp_layout.setVisibility(View.GONE);
                    wechat_layout.setVisibility(View.GONE);
                    platformDetails = "Facebook";
                } else if (parent.getItemAtPosition(position).toString().equals("WeChat")) {
                    facebookLayout.setVisibility(View.GONE);
                    whatsapp_layout.setVisibility(View.GONE);
                    wechat_layout.setVisibility(View.VISIBLE);
                    platformDetails = "WeChat";
                } else {
                    facebookLayout.setVisibility(View.GONE);
                    whatsapp_layout.setVisibility(View.VISIBLE);
                    wechat_layout.setVisibility(View.GONE);
                    platformDetails = "WhatsApp";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Toolbar toolbar = findViewById(R.id.interview_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        InterviewActivity.this.setTitle("Plan For Interview");

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_face_to_face:
                        submitBtn.setVisibility(View.VISIBLE);
                        online_interview_layout.setVisibility(View.GONE);
                        face_to_face_interview_layout.setVisibility(View.VISIBLE);
                        Calendar calender = Calendar.getInstance();
                        final int year = calender.get(Calendar.YEAR);
                        final int month = calender.get(Calendar.MONTH);
                        final int day = calender.get(Calendar.DAY_OF_MONTH);
                        face_date.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DatePickerDialog datePickerDialog = new DatePickerDialog(InterviewActivity.this, new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int month, int day) {
                                        month = month + 1;
                                        String date = day + "/" + month + "/" + year;
                                        face_date.setText(date);
                                    }
                                }, year, month, day);
                                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                                datePickerDialog.show();
                            }
                        });

                        face_time.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                LayoutInflater inflater = InterviewActivity.this.getLayoutInflater();
                                View theView = inflater.inflate(R.layout.time_picker, null);
                                hourPicker = (NumberPicker) theView.findViewById(R.id.hour_picker);
                                minPicker = (NumberPicker) theView.findViewById(R.id.min_picker);
                                AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.MaterialThemeDialog);
                                builder.setView(theView)
                                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                String hour = Integer.toString(hourPicker.getValue());
                                                String min = Integer.toString(minPicker.getValue());
                                                if (hour.equals("24")) {
                                                    hour = "00";
                                                }
                                                if (Integer.parseInt(hour) > 0 && Integer.parseInt(hour) < 10) {
                                                    hour = "0" + hour;
                                                }
                                                if (min.equals("0")) {
                                                    min = "00";
                                                }
                                                if (Integer.parseInt(min) > 0 && Integer.parseInt(min) < 10) {
                                                    min = "0" + min;
                                                }
                                                String time;
                                                time = hour + ":" + min;
                                                face_time.setText(time);

                                            }
                                        })
                                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                            }
                                        });
                                hourPicker.setMinValue(1);
                                hourPicker.setMaxValue(24);
                                minPicker.setMinValue(0);
                                minPicker.setMaxValue(59);
                                AlertDialog alertDialog = builder.create();
                                alertDialog.show();
                            }
                        });

                        submitBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                submitBtn.setClickable(false);
                                //Toast.makeText(InterviewActivity.this, location, Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.VISIBLE);
                                if (!isNetworkAvailable(InterviewActivity.this)) {
                                    progressBar.setVisibility(View.GONE);
                                    submitBtn.setClickable(true);
                                    AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.AlertDialogStyle);
                                    builder.setTitle(getString(R.string.connection_error))
                                            .setMessage(getString(R.string.error_description))
                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                }
                                            });

                                    AlertDialog alertDialog = builder.create();
                                    alertDialog.show();
                                } else {
                                    if (!face_interview_date() | !face_interview_time() | !face_interview_address()) {
                                        progressBar.setVisibility(View.GONE);
                                        submitBtn.setClickable(true);
                                        return;
                                    }

                                    firebaseFirestore.collection("Users")
                                            .document(ID)
                                            .collection("Notification")
                                            .document(jobID)
                                            .get()
                                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                    if (task.isSuccessful()) {
                                                        DocumentSnapshot document = task.getResult();
                                                        if (document.exists()) {
                                                            submitBtn.setClickable(true);
                                                            progressBar.setVisibility(View.GONE);
                                                            AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.AlertDialogStyle);
                                                            builder.setMessage("You Already Submit A Plan")
                                                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                                        @Override
                                                                        public void onClick(DialogInterface dialog, int which) {

                                                                        }
                                                                    });

                                                            AlertDialog alertDialog = builder.create();
                                                            alertDialog.show();
                                                        } else {
                                                            Date c = Calendar.getInstance().getTime();
                                                            System.out.println("Current time => " + c);
                                                            SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                            SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                            String formattedDate = df.format(c);
                                                            String formattedDateQuery = dfdate.format(c);

                                                            Map<Object, String> notificationdata = new HashMap<>();
                                                            notificationdata.put("JobCompany", companyName);
                                                            notificationdata.put("JobName", jobName);
                                                            notificationdata.put("Method", "Face to Face Interview");
                                                            notificationdata.put("InterviewDate", face_date.getText().toString().trim());
                                                            notificationdata.put("InterviewTime", face_time.getText().toString().trim());
                                                            notificationdata.put("InterviewPlatform", location);
                                                            notificationdata.put("InterviewPlatformDetails", face_address.getText().toString().trim());
                                                            notificationdata.put("InterviewMessage", face_message.getText().toString().trim());
                                                            notificationdata.put("JobID",jobID);
                                                            notificationdata.put("InterviewAcceptedDate",formattedDate);
                                                            notificationdata.put("InterviewAcceptedDateQuery",formattedDateQuery);

                                                            firebaseFirestore.collection("All Job")
                                                                    .document(jobID)
                                                                    .collection("AcceptedList")
                                                                    .document(ID)
                                                                    .set(notificationdata, SetOptions.merge())
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {

                                                                        }
                                                                    })
                                                                    .addOnFailureListener(new OnFailureListener() {
                                                                        @Override
                                                                        public void onFailure(@NonNull Exception e) {

                                                                        }
                                                                    });

                                                            firebaseFirestore.collection("Users")
                                                                    .document(ID)
                                                                    .collection("Notification")
                                                                    .document(jobID)
                                                                    .set(notificationdata, SetOptions.merge())
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {
                                                                            Toast.makeText(InterviewActivity.this, "Interview Successfully Planned!", Toast.LENGTH_SHORT).show();
                                                                            progressBar.setVisibility(View.GONE);
                                                                            submitBtn.setClickable(true);
                                                                        }
                                                                    }).addOnFailureListener(new OnFailureListener() {
                                                                @Override
                                                                public void onFailure(@NonNull Exception e) {
                                                                    Toast.makeText(InterviewActivity.this, "Failed to Plan Interview", Toast.LENGTH_SHORT).show();
                                                                    progressBar.setVisibility(View.GONE);
                                                                    submitBtn.setClickable(true);
                                                                }
                                                            });
                                                        }
                                                    } else {
                                                        Toast.makeText(InterviewActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                                        progressBar.setVisibility(View.GONE);
                                                        submitBtn.setClickable(true);
                                                    }
                                                }
                                            });


                                }
                            }
                        });
                        break;
                    case R.id.rb_online:
                        submitBtn.setVisibility(View.VISIBLE);
                        online_interview_layout.setVisibility(View.VISIBLE);
                        face_to_face_interview_layout.setVisibility(View.GONE);
                        Calendar online_calender = Calendar.getInstance();
                        final int online_year = online_calender.get(Calendar.YEAR);
                        final int online_month = online_calender.get(Calendar.MONTH);
                        final int online_day = online_calender.get(Calendar.DAY_OF_MONTH);
                        online_date.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DatePickerDialog datePickerDialog = new DatePickerDialog(InterviewActivity.this, new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int month, int day) {
                                        month = month + 1;
                                        String date = day + "/" + month + "/" + year;
                                        online_date.setText(date);
                                    }
                                }, online_year, online_month, online_day);
                                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                                datePickerDialog.show();
                            }
                        });

                        online_time.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                LayoutInflater inflater = InterviewActivity.this.getLayoutInflater();
                                View theView = inflater.inflate(R.layout.time_picker, null);
                                hourPicker = (NumberPicker) theView.findViewById(R.id.hour_picker);
                                minPicker = (NumberPicker) theView.findViewById(R.id.min_picker);
                                AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.MaterialThemeDialog);
                                builder.setView(theView)
                                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                String hour = Integer.toString(hourPicker.getValue());
                                                String min = Integer.toString(minPicker.getValue());
                                                if (hour.equals("24")) {
                                                    hour = "00";
                                                }
                                                if (Integer.parseInt(hour) > 0 && Integer.parseInt(hour) < 10) {
                                                    hour = "0" + hour;
                                                }
                                                if (min.equals("0")) {
                                                    min = "00";
                                                }
                                                if (Integer.parseInt(min) > 0 && Integer.parseInt(min) < 10) {
                                                    min = "0" + min;
                                                }
                                                String time;
                                                time = hour + ":" + min;
                                                online_time.setText(time);

                                            }
                                        })
                                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                            }
                                        });
                                hourPicker.setMinValue(1);
                                hourPicker.setMaxValue(24);
                                minPicker.setMinValue(0);
                                minPicker.setMaxValue(59);
                                AlertDialog alertDialog = builder.create();
                                alertDialog.show();
                            }
                        });

                        submitBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                submitBtn.setClickable(false);
                                //Toast.makeText(InterviewActivity.this, location, Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.VISIBLE);
                                if (!isNetworkAvailable(InterviewActivity.this)) {
                                    progressBar.setVisibility(View.GONE);
                                    submitBtn.setClickable(true);
                                    AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.AlertDialogStyle);
                                    builder.setTitle(getString(R.string.connection_error))
                                            .setMessage(getString(R.string.error_description))
                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                }
                                            });

                                    AlertDialog alertDialog = builder.create();
                                    alertDialog.show();
                                } else {
                                    if (!online_interview_date() | !online_interview_time()) {
                                        progressBar.setVisibility(View.GONE);
                                        submitBtn.setClickable(true);
                                        return;
                                    }
                                    if (platformDetails.equals("Facebook")) {
                                        if (!isValidUrl(online_platform_facebook.getText().toString().trim()) | !online_interview_facebook()) {
                                            progressBar.setVisibility(View.GONE);
                                            submitBtn.setClickable(true);
                                            return;
                                        } else {
                                            firebaseFirestore.collection("Users")
                                                    .document(ID)
                                                    .collection("Notification")
                                                    .document(jobID)
                                                    .get()
                                                    .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                            if (task.isSuccessful()) {
                                                                DocumentSnapshot documentSnapshot = task.getResult();
                                                                if (documentSnapshot.exists()) {
                                                                    submitBtn.setClickable(true);
                                                                    progressBar.setVisibility(View.GONE);
                                                                    AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.AlertDialogStyle);
                                                                    builder.setMessage("You Already Submit A Plan")
                                                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                                                @Override
                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                }
                                                                            });

                                                                    AlertDialog alertDialog = builder.create();
                                                                    alertDialog.show();
                                                                } else {
                                                                    Date c = Calendar.getInstance().getTime();
                                                                    System.out.println("Current time => " + c);
                                                                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                                    SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                                    String formattedDate = df.format(c);
                                                                    String formattedDateQuery = dfdate.format(c);

                                                                    String fbLink = online_platform_facebook.getText().toString().trim();
                                                                    Map<Object, String> notificationdata = new HashMap<>();
                                                                    notificationdata.put("JobCompany", companyName);
                                                                    notificationdata.put("JobName", jobName);
                                                                    notificationdata.put("Method", "Online Interview");
                                                                    notificationdata.put("InterviewDate", online_date.getText().toString().trim());
                                                                    notificationdata.put("InterviewTime", online_time.getText().toString().trim());
                                                                    notificationdata.put("InterviewPlatform", "Facebook");
                                                                    notificationdata.put("InterviewPlatformDetails", fbLink);
                                                                    notificationdata.put("InterviewMessage", online_message.getText().toString().trim());
                                                                    notificationdata.put("JobID",jobID);
                                                                    notificationdata.put("InterviewAcceptedDate",formattedDate);
                                                                    notificationdata.put("InterviewAcceptedDateQuery",formattedDateQuery);


                                                                    firebaseFirestore.collection("All Job")
                                                                            .document(jobID)
                                                                            .collection("AcceptedList")
                                                                            .document(ID)
                                                                            .set(notificationdata, SetOptions.merge())
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void aVoid) {

                                                                                }
                                                                            })
                                                                            .addOnFailureListener(new OnFailureListener() {
                                                                                @Override
                                                                                public void onFailure(@NonNull Exception e) {

                                                                                }
                                                                            });

                                                                    firebaseFirestore.collection("Users")
                                                                            .document(ID)
                                                                            .collection("Notification")
                                                                            .document(jobID)
                                                                            .set(notificationdata, SetOptions.merge())
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void aVoid) {
                                                                                    Toast.makeText(InterviewActivity.this, "Interview Successfully Planned!", Toast.LENGTH_SHORT).show();
                                                                                    progressBar.setVisibility(View.GONE);
                                                                                    submitBtn.setClickable(true);
                                                                                }
                                                                            }).addOnFailureListener(new OnFailureListener() {
                                                                        @Override
                                                                        public void onFailure(@NonNull Exception e) {
                                                                            Toast.makeText(InterviewActivity.this, "Failed to Plan Interview", Toast.LENGTH_SHORT).show();
                                                                            progressBar.setVisibility(View.GONE);
                                                                            submitBtn.setClickable(true);
                                                                        }
                                                                    });
                                                                }
                                                            } else {
                                                                Toast.makeText(InterviewActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                                                progressBar.setVisibility(View.GONE);
                                                                submitBtn.setClickable(true);
                                                            }

                                                        }
                                                    });

                                        }

                                    } else if (platformDetails.equals("WeChat")) {
                                        if (!online_interview_wechat()) {
                                            progressBar.setVisibility(View.GONE);
                                            submitBtn.setClickable(true);
                                            return;
                                        } else {
                                            firebaseFirestore.collection("Users")
                                                    .document(ID)
                                                    .collection("Notification")
                                                    .document(jobID)
                                                    .get()
                                                    .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                            if (task.isSuccessful()) {
                                                                DocumentSnapshot documentSnapshot = task.getResult();
                                                                if (documentSnapshot.exists()) {
                                                                    submitBtn.setClickable(true);
                                                                    progressBar.setVisibility(View.GONE);
                                                                    AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.AlertDialogStyle);
                                                                    builder.setMessage("You Already Submit A Plan")
                                                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                                                @Override
                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                }
                                                                            });

                                                                    AlertDialog alertDialog = builder.create();
                                                                    alertDialog.show();
                                                                } else {
                                                                    Date c = Calendar.getInstance().getTime();
                                                                    System.out.println("Current time => " + c);
                                                                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                                    SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                                    String formattedDate = df.format(c);
                                                                    String formattedDateQuery = dfdate.format(c);

                                                                    String wechatID = online_platform_wechat.getText().toString().trim();
                                                                    Map<Object, String> notificationdata = new HashMap<>();
                                                                    notificationdata.put("JobCompany", companyName);
                                                                    notificationdata.put("JobName", jobName);
                                                                    notificationdata.put("Method", "Online Interview");
                                                                    notificationdata.put("InterviewDate", online_date.getText().toString().trim());
                                                                    notificationdata.put("InterviewTime", online_time.getText().toString().trim());
                                                                    notificationdata.put("InterviewPlatform", "WeChat");
                                                                    notificationdata.put("InterviewPlatformDetails", wechatID);
                                                                    notificationdata.put("InterviewMessage", online_message.getText().toString().trim());
                                                                    notificationdata.put("JobID",jobID);
                                                                    notificationdata.put("InterviewAcceptedDate",formattedDate);
                                                                    notificationdata.put("InterviewAcceptedDateQuery",formattedDateQuery);

                                                                    firebaseFirestore.collection("All Job")
                                                                            .document(jobID)
                                                                            .collection("AcceptedList")
                                                                            .document(ID)
                                                                            .set(notificationdata, SetOptions.merge())
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void aVoid) {

                                                                                }
                                                                            })
                                                                            .addOnFailureListener(new OnFailureListener() {
                                                                                @Override
                                                                                public void onFailure(@NonNull Exception e) {

                                                                                }
                                                                            });

                                                                    firebaseFirestore.collection("Users")
                                                                            .document(ID)
                                                                            .collection("Notification")
                                                                            .document(jobID)
                                                                            .set(notificationdata, SetOptions.merge())
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void aVoid) {
                                                                                    Toast.makeText(InterviewActivity.this, "Interview Successfully Planned!", Toast.LENGTH_SHORT).show();
                                                                                    progressBar.setVisibility(View.GONE);
                                                                                    submitBtn.setClickable(true);
                                                                                }
                                                                            }).addOnFailureListener(new OnFailureListener() {
                                                                        @Override
                                                                        public void onFailure(@NonNull Exception e) {
                                                                            Toast.makeText(InterviewActivity.this, "Failed to Plan Interview", Toast.LENGTH_SHORT).show();
                                                                            progressBar.setVisibility(View.GONE);
                                                                            submitBtn.setClickable(true);
                                                                        }
                                                                    });
                                                                }
                                                            } else {
                                                                Toast.makeText(InterviewActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                                                progressBar.setVisibility(View.GONE);
                                                                submitBtn.setClickable(true);
                                                            }

                                                        }
                                                    });

                                        }

                                    } else if (platformDetails.equals("WhatsApp")) {
                                        if(!online_interview_whatsapp()){
                                            progressBar.setVisibility(View.GONE);
                                            submitBtn.setClickable(true);
                                            return;
                                        }else{
                                            firebaseFirestore.collection("Users")
                                                    .document(ID)
                                                    .collection("Notification")
                                                    .document(jobID)
                                                    .get()
                                                    .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                            if (task.isSuccessful()){
                                                                DocumentSnapshot documentSnapshot = task.getResult();
                                                                if(documentSnapshot.exists()){
                                                                    submitBtn.setClickable(true);
                                                                    progressBar.setVisibility(View.GONE);
                                                                    AlertDialog.Builder builder = new AlertDialog.Builder(InterviewActivity.this, R.style.AlertDialogStyle);
                                                                    builder.setMessage("You Already Submit A Plan")
                                                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                                                @Override
                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                }
                                                                            });

                                                                    AlertDialog alertDialog = builder.create();
                                                                    alertDialog.show();
                                                                }else{
                                                                    Date c = Calendar.getInstance().getTime();
                                                                    System.out.println("Current time => " + c);
                                                                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                                                                    SimpleDateFormat dfdate = new SimpleDateFormat("yyyyMMdd");
                                                                    String formattedDate = df.format(c);
                                                                    String formattedDateQuery = dfdate.format(c);

                                                                    String whatsAppNo = online_platform_whatsapp.getText().toString().trim();
                                                                    Map<Object, String> notificationdata = new HashMap<>();
                                                                    notificationdata.put("JobCompany", companyName);
                                                                    notificationdata.put("JobName", jobName);
                                                                    notificationdata.put("Method", "Online Interview");
                                                                    notificationdata.put("InterviewDate", online_date.getText().toString().trim());
                                                                    notificationdata.put("InterviewTime", online_time.getText().toString().trim());
                                                                    notificationdata.put("InterviewPlatform", "WhatsApp");
                                                                    notificationdata.put("InterviewPlatformDetails", whatsAppNo);
                                                                    notificationdata.put("InterviewMessage", online_message.getText().toString().trim());
                                                                    notificationdata.put("JobID",jobID);
                                                                    notificationdata.put("InterviewAcceptedDate",formattedDate);
                                                                    notificationdata.put("InterviewAcceptedDateQuery",formattedDateQuery);

                                                                    firebaseFirestore.collection("All Job")
                                                                            .document(jobID)
                                                                            .collection("AcceptedList")
                                                                            .document(ID)
                                                                            .set(notificationdata, SetOptions.merge())
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void aVoid) {

                                                                                }
                                                                            })
                                                                            .addOnFailureListener(new OnFailureListener() {
                                                                                @Override
                                                                                public void onFailure(@NonNull Exception e) {

                                                                                }
                                                                            });

                                                                    firebaseFirestore.collection("Users")
                                                                            .document(ID)
                                                                            .collection("Notification")
                                                                            .document(jobID)
                                                                            .set(notificationdata, SetOptions.merge())
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void aVoid) {
                                                                                    Toast.makeText(InterviewActivity.this, "Interview Successfully Planned!", Toast.LENGTH_SHORT).show();
                                                                                    progressBar.setVisibility(View.GONE);
                                                                                    submitBtn.setClickable(true);
                                                                                }
                                                                            }).addOnFailureListener(new OnFailureListener() {
                                                                        @Override
                                                                        public void onFailure(@NonNull Exception e) {
                                                                            Toast.makeText(InterviewActivity.this, "Failed to Plan Interview", Toast.LENGTH_SHORT).show();
                                                                            progressBar.setVisibility(View.GONE);
                                                                            submitBtn.setClickable(true);
                                                                        }
                                                                    });
                                                                }
                                                            }else{
                                                                Toast.makeText(InterviewActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                                                progressBar.setVisibility(View.GONE);
                                                                submitBtn.setClickable(true);
                                                            }

                                                        }
                                                    });

                                        }

                                    }

                                }
                            }
                        });
                        break;
                }
            }
        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private boolean face_interview_date() {
        String date = face_date.getText().toString().trim();
        if (date.isEmpty()) {
            face_date.setError("Field can't be empty!");
            return false;
        } else {
            face_date.setError(null);
            return true;
        }
    }

    private boolean face_interview_time() {
        String time = face_time.getText().toString().trim();
        if (time.isEmpty()) {
            face_time.setError("Field can't be empty!");
            return false;
        } else {
            face_date.setError(null);
            return true;
        }
    }

    private boolean isValidUrl(String url) {
        Pattern p = Patterns.WEB_URL;
        Matcher m = p.matcher(url.toLowerCase());
        if (m.matches()) {
            return true;
        } else {
            online_platform_facebook.setError("Not A Valid Link!");
            return false;
        }
    }

    private boolean online_interview_date() {
        String date = online_date.getText().toString().trim();
        if (date.isEmpty()) {
            online_date.setError("Field can't be empty!");
            return false;
        } else {
            online_date.setError(null);
            return true;
        }
    }

    private boolean online_interview_facebook() {
        String fbLink = online_platform_facebook.getText().toString().trim();
        if (fbLink.isEmpty()) {
            online_platform_facebook.setError("Field can't be empty!");
            return false;
        } else {
            online_platform_facebook.setError(null);
            return true;
        }
    }

    private boolean online_interview_wechat() {
        String fbLink = online_platform_wechat.getText().toString().trim();
        if (fbLink.isEmpty()) {
            online_platform_wechat.setError("Field can't be empty!");
            return false;
        } else {
            online_platform_wechat.setError(null);
            return true;
        }
    }

    private boolean online_interview_whatsapp() {
        String fbLink = online_platform_whatsapp.getText().toString().trim();
        if (fbLink.isEmpty()) {
            online_platform_whatsapp.setError("Field can't be empty!");
            return false;
        } else {
            ;
            online_platform_whatsapp.setError(null);
            return true;
        }
    }

    private boolean online_interview_time() {
        String time = online_time.getText().toString().trim();
        if (time.isEmpty()) {
            online_time.setError("Field can't be empty!");
            return false;
        } else {
            online_time.setError(null);
            return true;
        }
    }


    private boolean face_interview_address() {
        String address = face_address.getText().toString().trim();
        if (address.isEmpty()) {
            face_address.setError("Field can't be empty!");
            return false;
        } else {
            face_address.setError(null);
            return true;
        }
    }

    public static boolean isNetworkAvailable(Context con) {
        try {
            ConnectivityManager cm = (ConnectivityManager) con
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}
