package com.example.jobseekers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class InterviewDetails extends AppCompatActivity {

    private TextView JobTitle,JobCompany,Date,Time,Method,Place,PlaceDetails,Message;
    private Button confirmBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interview_details);
        Intent intent = getIntent();
        String jobName = intent.getStringExtra("jobName");
        String jobCompany = intent.getStringExtra("jobCompany");
        String jobDate = intent.getStringExtra("date");
        String jobTime = intent.getStringExtra("time");
        String jobMethod = intent.getStringExtra("method");
        String jobPlace = intent.getStringExtra("place");
        String jobPlaceDetails = intent.getStringExtra("placeDetails");
        String jobMessage = intent.getStringExtra("message");

        final Toolbar toolbar = findViewById(R.id.interview_details_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        InterviewDetails.this.setTitle("Interview Details");

        JobTitle = (TextView)findViewById(R.id.interview_details_job_title);
        JobCompany = (TextView)findViewById(R.id.interview_details_job_company);
        Date = (TextView)findViewById(R.id.interview_details_date);
        Time = (TextView)findViewById(R.id.interview_details_time);
        Method = (TextView)findViewById(R.id.interview_details_method);
        Place = (TextView)findViewById(R.id.interview_details_place);
        PlaceDetails = (TextView)findViewById(R.id.interview_details_place_details);
        Message = (TextView)findViewById(R.id.interview_details_message);
        confirmBtn = (Button)findViewById(R.id.interview_details_confirm);

        JobTitle.setText(jobName);
        JobCompany.setText(jobCompany);
        Date.setText(jobDate);
        Time.setText(jobTime);
        Method.setText(jobMethod);
        Place.setText(jobPlace);
        PlaceDetails.setText(jobPlaceDetails);
        if(jobMessage.equals("")){
            Message.setText("No Message");
        }else{
            Message.setText(jobMessage);
        }


        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
